# LiveDrop — Application de livraison Flutter

Application mobile complète iOS + Android pour la livraison entre particuliers et entreprises.

---

## Stack technique

| Couche | Technologie |
|---|---|
| Framework mobile | Flutter 3.10+ (Dart) |
| Navigation | go_router |
| State management | Provider + ChangeNotifier |
| Cartes / GPS | google_maps_flutter + geolocator |
| QR Code | mobile_scanner + qr_flutter |
| Paiements | flutter_stripe (Stripe Connect) |
| Temps réel | socket_io_client (WebSocket) |
| Notifications push | firebase_messaging |
| Base de données | Firebase Firestore |
| Auth | Firebase Auth |
| Stockage sécurisé | flutter_secure_storage |

---

## Installation

### Prérequis
- Flutter SDK 3.10+ installé : https://flutter.dev/docs/get-started/install
- Android Studio ou VS Code avec plugin Flutter
- Xcode (pour iOS, Mac uniquement)
- Compte Firebase (gratuit)
- Compte Google Cloud (pour Google Maps API)
- Compte Stripe (pour les paiements)

### 1. Cloner et installer les dépendances

```bash
git clone https://github.com/votre-repo/livedrop
cd livedrop
flutter pub get
```

### 2. Configurer Firebase

```bash
# Installer FlutterFire CLI
dart pub global activate flutterfire_cli

# Configurer votre projet Firebase
flutterfire configure
```

Cela génère automatiquement `lib/firebase_options.dart`.

Dans `lib/main.dart`, décommenter :
```dart
await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
```

### 3. Configurer Google Maps

**Android** — dans `android/app/src/main/AndroidManifest.xml`, remplacer :
```
${GOOGLE_MAPS_API_KEY}
```
par votre clé API Google Maps.

**iOS** — dans `ios/Runner/AppDelegate.swift`, ajouter :
```swift
GMSServices.provideAPIKey("VOTRE_CLE_GOOGLE_MAPS")
```

### 4. Configurer Stripe

Dans `lib/main.dart`, ajouter avant `runApp` :
```dart
Stripe.publishableKey = 'pk_live_VOTRE_CLE_PUBLIQUE';
```

Pour les virements livreurs, configurer Stripe Connect dans votre dashboard Stripe.

### 5. Lancer l'application

```bash
# Android
flutter run --release

# iOS
flutter run --release -d iphone
```

---

## Architecture du projet

```
lib/
├── main.dart                    # Point d'entrée
├── router.dart                  # Navigation go_router
├── core/
│   └── theme/
│       └── app_theme.dart       # Thème futuriste sombre
├── models/
│   └── models.dart              # Tous les modèles de données
├── providers/
│   └── providers.dart           # State management (AuthProvider, DeliveryProvider, DriverProvider...)
├── services/
│   └── services.dart            # API, Paiement, GPS, QR, Notifications
├── widgets/
│   └── common/
│       └── widgets.dart         # Composants réutilisables (LDButton, LDCard, LDTag...)
└── screens/
    ├── splash/                  # Écran de démarrage animé
    ├── auth/                    # Onboarding, Login, Register
    ├── client/
    │   ├── home_screen.dart         # Accueil client
    │   ├── create_delivery/         # Tunnel en 4 étapes
    │   │   ├── step1_address_screen.dart
    │   │   ├── step2_package_screen.dart
    │   │   ├── step3_details_screen.dart
    │   │   └── step4_payment_screen.dart
    │   ├── finding_screen.dart      # Recherche livreur (animé)
    │   ├── tracking_screen.dart     # Suivi GPS temps réel
    │   ├── chat_screen.dart         # Chat client ↔ livreur
    │   ├── delivered_screen.dart    # Livraison confirmée + notation
    │   ├── history_screen.dart      # Historique filtrable
    │   ├── notifications_screen.dart
    │   └── profile_screen.dart
    └── driver/
        ├── home_screen.dart         # Dashboard livreur (carte + missions + gains)
        ├── mission_detail_screen.dart # Détail mission + timer 45s
        ├── navigation_screen.dart    # GPS navigation
        ├── qr_scan_screen.dart       # Scanner QR pickup/delivery + photo preuve
        ├── paid_screen.dart          # Confirmation paiement
        ├── earnings_screen.dart      # Tableau de bord financier
        └── driver_profile_screen.dart # Profil + score fiabilité
```

---

## Fonctionnalités complètes

### Application Client
- [x] Onboarding 3 slides animé
- [x] Authentification (email, Apple, Google)
- [x] Création livraison en 4 étapes (adresses, type/taille, détails/photo, paiement)
- [x] Calcul de prix dynamique (distance + type + options)
- [x] 6 types de colis (colis, repas, meuble, document, médicament, fleurs)
- [x] 4 tailles de colis avec tarifs différenciés
- [x] Options : assurance, fragile, livraison planifiée
- [x] Photo du colis (preuve avant expédition)
- [x] Coordonnées destinataire
- [x] Choix du mode de paiement (carte, Apple Pay, Google Pay, wallet)
- [x] Code promo
- [x] Animation de recherche de livreur
- [x] Suivi GPS en temps réel avec carte
- [x] ETA dynamique
- [x] Infos livreur (nom, note, véhicule, badge vérifié)
- [x] Chat temps réel avec réponses rapides
- [x] Timeline de livraison en direct
- [x] Alerte géofencing si déviation
- [x] Reçu détaillé après livraison
- [x] Notation étoiles + tags rapides + commentaire
- [x] Historique filtrable par type
- [x] Notifications push
- [x] Profil complet (stats, wallet, adresses, paiements, parrainage)

### Application Livreur
- [x] Dashboard temps réel (gains, livraisons, streak, graphique semaine)
- [x] Toggle en ligne/hors ligne
- [x] Carte des missions disponibles
- [x] Liste de missions avec gains nets après commission
- [x] Détail mission complet (route, client, instructions, gains)
- [x] Timer 45s pour accepter/refuser
- [x] Navigation GPS point A (pickup) avec indicateur vitesse
- [x] Scan QR code au point A (collecte)
- [x] Navigation GPS point B (livraison)
- [x] Scan QR code + photo obligatoire au point B
- [x] Alerte géofencing si déviation trajet
- [x] Confirmation paiement avec détail commission (20%)
- [x] Bonus streak
- [x] Tableau de bord financier (graphique, taux horaire, virement)
- [x] Historique des missions du jour
- [x] Profil complet (score fiabilité, véhicule, documents)
- [x] 4 métriques de qualité avec barres de progression

---

## Modèle économique implémenté

- Commission automatique **20%** prélevée à chaque livraison validée
- Fonds client bloqués à la commande (escrow Stripe)
- Libération automatique au scan QR de livraison
- Virements livreurs via Stripe Connect
- Portefeuille client (crédits, remboursements)

---

## Sécurité

- Géofencing : alerte si le livreur s'écarte de plus de 2 km du trajet optimal
- Score livreur calculé sur 4 métriques (ponctualité, soin, communication, trajet)
- Vérification identité obligatoire à l'inscription livreur
- Photo preuve de livraison horodatée et géolocalisée
- QR codes uniques par livraison (pickup + dropoff)
- Paiement chiffré SSL via Stripe

---

## Variables d'environnement à configurer

Créer un fichier `.env` à la racine :

```
GOOGLE_MAPS_API_KEY=AIza...
STRIPE_PUBLISHABLE_KEY=pk_live_...
STRIPE_SECRET_KEY=sk_live_...
FIREBASE_PROJECT_ID=livedrop-xxxxx
API_BASE_URL=https://api.livedrop.fr/v1
```

---

## Prochaines étapes (post-MVP)

- [ ] Intégration Google Maps réelle (remplacer CustomPainter)
- [ ] Connexion backend Node.js (remplacer les mocks)
- [ ] WebSocket temps réel pour positions GPS
- [ ] Firebase Auth complet
- [ ] Stripe Connect production
- [ ] Tests unitaires et E2E (Flutter Test + integration_test)
- [ ] CI/CD (GitHub Actions → App Store / Play Store)
- [ ] Support multilingue (intl)
- [ ] Mode sombre/clair automatique
- [ ] Livraisons planifiées
- [ ] Algorithme de pricing dynamique (surge)
- [ ] Support véhicules XXL (utilitaire)
