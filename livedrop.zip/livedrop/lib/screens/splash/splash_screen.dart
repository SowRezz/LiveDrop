import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/theme/app_theme.dart';
import '../../widgets/common/widgets.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _fade;
  late Animation<double> _slide;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900));
    _fade = CurvedAnimation(parent: _ctrl, curve: Curves.easeOut);
    _slide = Tween<double>(begin: 30, end: 0)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOut));
    _ctrl.forward();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment(0, -0.4),
            radius: 1.2,
            colors: [Color(0xFF0D1A2E), AppColors.bg],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 28),
            child: FadeTransition(
              opacity: _fade,
              child: AnimatedBuilder(
                animation: _slide,
                builder: (_, child) =>
                    Transform.translate(offset: Offset(0, _slide.value), child: child),
                child: Column(
                  children: [
                    const Spacer(flex: 2),
                    RichText(
                      text: const TextSpan(
                        style: TextStyle(
                            fontFamily: 'Syne',
                            fontSize: 52,
                            fontWeight: FontWeight.w800,
                            letterSpacing: -2),
                        children: [
                          TextSpan(
                              text: 'Live',
                              style: TextStyle(color: AppColors.textPrimary)),
                          TextSpan(
                              text: 'Drop',
                              style: TextStyle(color: AppColors.yellow)),
                        ],
                      ),
                    ),
                    const SizedBox(height: 10),
                    const Text(
                      "Livrez n'importe quoi,\nn'importe où, maintenant.",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          fontSize: 15,
                          color: AppColors.textSecondary,
                          height: 1.6),
                    ),
                    const SizedBox(height: 40),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        _stat('30 min', 'délai moyen'),
                        Container(
                            width: 1,
                            height: 36,
                            color: AppColors.border,
                            margin: const EdgeInsets.symmetric(horizontal: 20)),
                        _stat('4.9 ★', 'livreurs'),
                        Container(
                            width: 1,
                            height: 36,
                            color: AppColors.border,
                            margin: const EdgeInsets.symmetric(horizontal: 20)),
                        _stat('+12k', 'livraisons'),
                      ],
                    ),
                    const SizedBox(height: 48),
                    LDButton(
                        label: 'Commencer →',
                        color: AppColors.yellow,
                        onTap: () => context.go('/onboarding')),
                    const SizedBox(height: 10),
                    LDButton(
                        label: 'Déjà un compte',
                        outline: true,
                        onTap: () => context.go('/auth/login')),
                    const Spacer(),
                    const Text(
                      'En continuant, vous acceptez nos CGU et Politique de confidentialité',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          fontSize: 11,
                          color: AppColors.textTertiary,
                          height: 1.5),
                    ),
                    const SizedBox(height: 20),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _stat(String val, String lbl) => Column(
        children: [
          Text(val,
              style: const TextStyle(
                  fontFamily: 'Syne',
                  fontSize: 18,
                  fontWeight: FontWeight.w800,
                  color: AppColors.yellow)),
          Text(lbl,
              style: const TextStyle(
                  fontSize: 11, color: AppColors.textSecondary)),
        ],
      );
}
