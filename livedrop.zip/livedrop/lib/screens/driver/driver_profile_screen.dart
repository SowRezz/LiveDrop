
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../models/models.dart';
import '../../providers/providers.dart';
import '../../widgets/common/widgets.dart';

class DriverProfileScreen extends StatelessWidget {
  const DriverProfileScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final dp = context.watch<DriverProvider>();
    final driver = dp.driver ?? DriverModel.mock;
    final auth = context.watch<AuthProvider>();

    return Scaffold(
      appBar: AppBar(title: const Text('Mon profil', style: TextStyle(fontFamily: 'Syne', fontSize: 20, fontWeight: FontWeight.w700))),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(children: [
            CircleAvatar(radius: 38, backgroundColor: AppColors.surface3,
              child: Text(driver.firstName[0], style: const TextStyle(fontFamily: 'Syne', fontSize: 32, fontWeight: FontWeight.w800, color: AppColors.textPrimary))),
            const SizedBox(height: 12),
            Text(driver.fullName, style: const TextStyle(fontFamily: 'Syne', fontSize: 20, fontWeight: FontWeight.w700)),
            const Text('Livreur verifie · Moto', style: TextStyle(fontSize: 12, color: AppColors.textSecondary)),
            const SizedBox(height: 8),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              LDTag.green('Verifie'),
              const SizedBox(width: 6),
              LDTag.cyan('Top livreur'),
              const SizedBox(width: 6),
              LDTag.purple('Streak x${driver.currentStreak}🔥'),
            ]),
            const SizedBox(height: 24),
            // Score detail
            LDCard(
              borderColor: AppColors.cyan.withOpacity(0.2),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('SCORE DE FIABILITE', style: TextStyle(fontFamily: 'Syne', fontSize: 12, fontWeight: FontWeight.w600)),
                const SizedBox(height: 12),
                Row(children: [
                  Text('${driver.score.overall}', style: const TextStyle(fontFamily: 'Syne', fontSize: 36, fontWeight: FontWeight.w800, color: AppColors.cyan)),
                  const SizedBox(width: 12),
                  Row(children: List.generate(5, (i) => Text('*', style: TextStyle(fontSize: 22, color: i < driver.score.overall.floor() ? AppColors.yellow : AppColors.surface4)))),
                ]),
                const SizedBox(height: 14),
                ...[
                  ['Ponctualite', driver.score.punctuality],
                  ['Soin du colis', driver.score.packageCare],
                  ['Communication', driver.score.communication],
                  ['Respect trajet', driver.score.routeCompliance],
                ].map((e) => Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: Row(children: [
                    SizedBox(width: 110, child: Text(e[0] as String, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary))),
                    Expanded(child: LDProgressBar(value: e[1] as double, color: (e[1] as double) > 0.9 ? AppColors.green : AppColors.cyan)),
                    const SizedBox(width: 8),
                    Text('${((e[1] as double) * 100).round()}%', style: const TextStyle(fontFamily: 'SpaceMono', fontSize: 10, color: AppColors.textSecondary)),
                  ]),
                )),
              ]),
            ),
            GridView.count(
              shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
              crossAxisCount: 2, mainAxisSpacing: 10, crossAxisSpacing: 10, childAspectRatio: 1.8,
              children: [
                StatBox(value: '${driver.totalDeliveries}', label: 'LIVRAISONS TOTAL', valueColor: AppColors.yellow),
                StatBox(value: '${driver.weekEarnings.toStringAsFixed(0)} EUR', label: 'CE MOIS', valueColor: AppColors.cyan),
                StatBox(value: '${driver.acceptanceRate.round()}%', label: 'TAUX ACCEPT.', valueColor: AppColors.green),
                StatBox(value: '${driver.currentStreak}🔥', label: 'STREAK', valueColor: AppColors.purple),
              ],
            ),
            const SizedBox(height: 14),
            LDCard(child: Row(children: [
              Text(driver.vehicleEmoji, style: const TextStyle(fontSize: 28)),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(driver.vehicleBrand, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500)),
                Text(driver.vehiclePlate, style: const TextStyle(fontFamily: 'SpaceMono', fontSize: 11, color: AppColors.textSecondary)),
              ])),
              LDTag.green('CT OK'),
            ])),
            Container(
              decoration: BoxDecoration(color: AppColors.surface2, borderRadius: BorderRadius.circular(16), border: Border.all(color: AppColors.border)),
              child: Column(children: [
                _mi('📄', 'Mes documents'),
                _mi('🏦', 'Coordonnees bancaires'),
                _mi('🔔', 'Notifications'),
                _mi('❓', 'Aide et support'),
              ]),
            ),
            const SizedBox(height: 12),
            LDButton(label: 'Se deconnecter', outline: true, textColor: AppColors.red, onTap: () { auth.logout(); context.go('/splash'); }),
          ]),
        ),
      ),
    );
  }
  Widget _mi(String ico, String label) => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
    child: Row(children: [
      Text(ico, style: const TextStyle(fontSize: 18)), const SizedBox(width: 12),
      Expanded(child: Text(label, style: const TextStyle(fontSize: 13))),
      const Icon(Icons.chevron_right, size: 18, color: AppColors.textTertiary),
    ]),
  );
}
