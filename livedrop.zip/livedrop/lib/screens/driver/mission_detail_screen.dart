
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../models/models.dart';
import '../../providers/providers.dart';
import '../../widgets/common/widgets.dart';

class MissionDetailScreen extends StatefulWidget {
  final String deliveryId;
  const MissionDetailScreen({super.key, required this.deliveryId});
  @override
  State<MissionDetailScreen> createState() => _MissionDetailState();
}

class _MissionDetailState extends State<MissionDetailScreen> {
  MissionModel? _mission;

  @override
  void initState() {
    super.initState();
    final dp = context.read<DriverProvider>();
    _mission = dp.availableMissions.cast<MissionModel?>().firstWhere(
      (m) => m?.deliveryId == widget.deliveryId,
      orElse: () => MissionModel.mockList.first,
    );
    dp.startMissionTimer(() {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Mission expiree'), backgroundColor: AppColors.red));
        context.go('/driver');
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final dp = context.watch<DriverProvider>();
    final m = _mission ?? MissionModel.mockList.first;
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(icon: const Icon(Icons.arrow_back, size: 20), onPressed: () => context.go('/driver')),
        title: const Text('Detail mission', style: TextStyle(fontFamily: 'Syne', fontSize: 17, fontWeight: FontWeight.w700)),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [AppColors.green.withOpacity(0.08), AppColors.green.withOpacity(0.02)]),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppColors.green.withOpacity(0.2)),
              ),
              child: Row(children: [
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('VOS GAINS', style: TextStyle(fontFamily: 'SpaceMono', fontSize: 10, color: AppColors.textSecondary)),
                  Text('+ ${m.driverEarnings.toStringAsFixed(2)} EUR', style: const TextStyle(fontFamily: 'Syne', fontSize: 32, fontWeight: FontWeight.w800, color: AppColors.green)),
                  Text('Prix total ${m.totalAmount.toStringAsFixed(2)} EUR — Comm. 20%', style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                ]),
                const Spacer(),
                LDTag.green('Credit a livraison'),
              ]),
            ),
            const SizedBox(height: 14),
            LDCard(
              borderColor: AppColors.cyan.withOpacity(0.2),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Column(children: [
                    Container(width: 8, height: 8, decoration: const BoxDecoration(color: AppColors.yellow, shape: BoxShape.circle)),
                    Container(width: 1, height: 26, color: AppColors.border),
                    Container(width: 8, height: 8, decoration: BoxDecoration(color: AppColors.cyan, borderRadius: BorderRadius.circular(2))),
                  ]),
                  const SizedBox(width: 12),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(m.pickupLocation.address, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500)),
                    const SizedBox(height: 14),
                    Text(m.dropoffLocation.address, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500)),
                  ])),
                ]),
                const SizedBox(height: 10),
                Wrap(spacing: 6, children: [
                  LDTag.yellow('${m.package.typeEmoji} ${m.package.typeLabel}'),
                  LDTag.cyan('${m.totalDistanceKm.toStringAsFixed(1)} km'),
                  LDTag.green('~${m.estimatedMinutes} min'),
                ]),
              ]),
            ),
            LDCard(child: Row(children: [
              CircleAvatar(radius: 18, backgroundColor: AppColors.surface3,
                child: Text(m.clientName[0], style: const TextStyle(fontFamily: 'Syne', fontWeight: FontWeight.w700, color: AppColors.textPrimary))),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(m.clientName, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500)),
                Text('${m.clientRating} ★ · Client verifie', style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
              ])),
              LDTag.green('Verifie'),
            ])),
            if (m.clientInstructions != null)
              LDCard(
                color: AppColors.orange.withOpacity(0.06),
                borderColor: AppColors.orange.withOpacity(0.2),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('INSTRUCTIONS', style: TextStyle(fontFamily: 'SpaceMono', fontSize: 10, color: AppColors.orange)),
                  const SizedBox(height: 6),
                  Text(m.clientInstructions!, style: const TextStyle(fontSize: 13, height: 1.4)),
                ]),
              ),
            Container(
              padding: const EdgeInsets.all(12),
              margin: const EdgeInsets.only(bottom: 10),
              decoration: BoxDecoration(color: AppColors.orange.withOpacity(0.08), borderRadius: BorderRadius.circular(10), border: Border.all(color: AppColors.orange.withOpacity(0.2))),
              child: Row(children: [
                const Text('Acceptez dans ', style: TextStyle(fontSize: 12, color: AppColors.orange)),
                Text('${dp.timerSeconds}s', style: const TextStyle(fontFamily: 'SpaceMono', fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.orange)),
                const Text(' — redistribuee sinon', style: TextStyle(fontSize: 12, color: AppColors.orange)),
              ]),
            ),
            LDProgressBar(value: dp.timerSeconds / 45, color: AppColors.orange),
            const SizedBox(height: 16),
            Row(children: [
              Expanded(child: LDButton(label: 'Refuser', outline: true, onTap: () { dp.refuseMission(m.deliveryId); context.go('/driver'); })),
              const SizedBox(width: 10),
              Expanded(flex: 2, child: LDButton(label: 'Accepter ->', onTap: () { dp.acceptMission(m); context.go('/driver/navigate/a'); })),
            ]),
          ]),
        ),
      ),
    );
  }
}
