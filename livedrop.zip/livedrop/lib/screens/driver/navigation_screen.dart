
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../models/models.dart';
import '../../providers/providers.dart';
import '../../widgets/common/widgets.dart';

class NavigationScreen extends StatelessWidget {
  final bool isPickup;
  const NavigationScreen({super.key, required this.isPickup});

  @override
  Widget build(BuildContext context) {
    final dp = context.watch<DriverProvider>();
    final m = dp.activeMission ?? MissionModel.mockList.first;
    final dest = isPickup ? m.pickupLocation : m.dropoffLocation;
    final color = isPickup ? AppColors.yellow : AppColors.cyan;

    return Scaffold(
      body: SafeArea(
        child: Stack(children: [
          Container(
            decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF0A1420), Color(0xFF0D1828)])),
            child: CustomPaint(size: Size.infinite, painter: _NavPainter(isPickup: isPickup, color: color)),
          ),
          Positioned(top: 12, left: 12, right: 12,
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: const Color(0xFF0D1220).withOpacity(0.92), borderRadius: BorderRadius.circular(14), border: Border.all(color: color.withOpacity(0.3))),
              child: Row(children: [
                Container(width: 40, height: 40, decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(8)),
                  child: const Center(child: Icon(Icons.arrow_upward, color: Color(0xFF060C16), size: 22))),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(dest.address.split(',').first, style: const TextStyle(fontFamily: 'Syne', fontSize: 14, fontWeight: FontWeight.w700)),
                  const Text('Tout droit', style: TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                ])),
                Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                  Text('${(m.distanceToPickupKm * 4).round()} min', style: const TextStyle(fontFamily: 'Syne', fontSize: 18, fontWeight: FontWeight.w800)),
                  Text('${m.distanceToPickupKm.toStringAsFixed(1)} km', style: const TextStyle(fontFamily: 'SpaceMono', fontSize: 10, color: AppColors.textSecondary)),
                ]),
              ]),
            ),
          ),
          Positioned(bottom: 120, right: 12,
            child: Container(
              width: 44, height: 44,
              decoration: BoxDecoration(color: const Color(0xFF0D1220).withOpacity(0.9), border: Border.all(color: color, width: 2), borderRadius: BorderRadius.circular(8)),
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                Text('38', style: TextStyle(fontFamily: 'SpaceMono', fontSize: 13, fontWeight: FontWeight.w700, color: color)),
                const Text('km/h', style: TextStyle(fontSize: 8, color: AppColors.textSecondary)),
              ]),
            ),
          ),
          Positioned(bottom: 0, left: 0, right: 0,
            child: Container(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 20),
              decoration: BoxDecoration(color: const Color(0xFF0D1220).withOpacity(0.95), border: const Border(top: BorderSide(color: AppColors.border))),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('DEST ${isPickup ? "A — PICKUP" : "B — LIVRAISON"}', style: const TextStyle(fontFamily: 'SpaceMono', fontSize: 10, color: AppColors.textSecondary)),
                const SizedBox(height: 2),
                Text(dest.address, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500)),
                const SizedBox(height: 12),
                Row(children: [
                  LDButton(label: 'Annuler', outline: true, width: 100, onTap: () => context.go('/driver')),
                  const SizedBox(width: 10),
                  Expanded(child: LDButton(
                    label: 'Arrive — Scanner QR ->',
                    onTap: () => context.go(isPickup ? '/driver/scan/pickup' : '/driver/scan/delivery'),
                  )),
                ]),
              ]),
            ),
          ),
        ]),
      ),
    );
  }
}

class _NavPainter extends CustomPainter {
  final bool isPickup;
  final Color color;
  const _NavPainter({required this.isPickup, required this.color});
  @override
  void paint(Canvas canvas, Size s) {
    final g = Paint()..color = AppColors.cyan.withOpacity(0.04)..strokeWidth = 1;
    for (double x = 0; x < s.width; x += 28) canvas.drawLine(Offset(x, 0), Offset(x, s.height), g);
    for (double y = 0; y < s.height; y += 28) canvas.drawLine(Offset(0, y), Offset(s.width, y), g);
    final r = Paint()..color = Colors.white.withOpacity(0.07)..strokeWidth = 5;
    canvas.drawLine(Offset(0, s.height * 0.44), Offset(s.width, s.height * 0.44), r);
    canvas.drawLine(Offset(s.width * 0.3, 0), Offset(s.width * 0.3, s.height), r);
    final rp = Paint()..color = color.withOpacity(0.5)..strokeWidth = 3..style = PaintingStyle.stroke;
    final p = Path()..moveTo(s.width * 0.6, s.height * 0.6)..cubicTo(s.width * 0.6, s.height * 0.44, s.width * 0.3, s.height * 0.44, s.width * 0.3, s.height * 0.3);
    canvas.drawPath(p, rp);
    canvas.drawCircle(Offset(s.width * 0.6, s.height * 0.6), 8, Paint()..color = AppColors.cyan);
    canvas.drawCircle(Offset(s.width * 0.6, s.height * 0.6), 14, Paint()..color = AppColors.cyan.withOpacity(0.2));
    canvas.drawCircle(Offset(s.width * 0.3, s.height * 0.3), 12, Paint()..color = color);
    final tp = TextPainter(text: TextSpan(text: isPickup ? 'A' : 'B', style: const TextStyle(color: Color(0xFF060C16), fontSize: 10, fontWeight: FontWeight.w700)), textDirection: TextDirection.ltr)..layout();
    tp.paint(canvas, Offset(s.width * 0.3 - tp.width / 2, s.height * 0.3 - tp.height / 2));
  }
  @override
  bool shouldRepaint(_) => false;
}
