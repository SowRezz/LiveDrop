
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../models/models.dart';
import '../../providers/providers.dart';
import '../../widgets/common/widgets.dart';

class EarningsScreen extends StatelessWidget {
  const EarningsScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final dp = context.watch<DriverProvider>();
    final driver = dp.driver ?? DriverModel.mock;
    final week = EarningsPeriod.mockWeek;
    final maxAmt = week.map((e) => e.amount).reduce((a, b) => a > b ? a : b);
    final dayLabels = ['L', 'M', 'M', 'J', 'V', 'S', 'D'];
    return Scaffold(
      appBar: AppBar(title: const Text('Mes gains', style: TextStyle(fontFamily: 'Syne', fontSize: 20, fontWeight: FontWeight.w700))),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [AppColors.cyan.withOpacity(0.08), AppColors.cyan.withOpacity(0.02)]),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppColors.cyan.withOpacity(0.2)),
              ),
              child: Row(children: [
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('AUJOURD\'HUI', style: TextStyle(fontFamily: 'SpaceMono', fontSize: 10, color: AppColors.textSecondary)),
                  Text('${driver.todayEarnings.toStringAsFixed(2)} EUR', style: const TextStyle(fontFamily: 'Syne', fontSize: 36, fontWeight: FontWeight.w800, color: AppColors.cyan)),
                  Text('${driver.todayDeliveries} livraisons · 3h 24m', style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                ]),
                const Spacer(),
                Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                  const Text('vs hier', style: TextStyle(fontSize: 10, color: AppColors.textSecondary)),
                  const Text('↑ +12%', style: TextStyle(fontFamily: 'Syne', fontSize: 16, fontWeight: FontWeight.w700, color: AppColors.green)),
                ]),
              ]),
            ),
            const SizedBox(height: 14),
            LDCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('GAINS CETTE SEMAINE', style: TextStyle(fontFamily: 'Syne', fontSize: 12, fontWeight: FontWeight.w600)),
              const SizedBox(height: 12),
              SizedBox(
                height: 80,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: List.generate(week.length, (i) {
                    final f = week[i].amount / maxAmt;
                    final isToday = i == week.length - 2;
                    return Expanded(child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 3),
                      child: Column(mainAxisAlignment: MainAxisAlignment.end, children: [
                        Container(
                          height: 70 * f,
                          decoration: BoxDecoration(
                            color: isToday ? AppColors.cyan : AppColors.cyan.withOpacity(0.3 + f * 0.2),
                            borderRadius: BorderRadius.circular(4),
                            boxShadow: isToday ? [BoxShadow(color: AppColors.cyan.withOpacity(0.3), blurRadius: 8)] : null,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(dayLabels[i], style: TextStyle(fontFamily: 'SpaceMono', fontSize: 9, color: isToday ? AppColors.cyan : AppColors.textTertiary)),
                      ]),
                    ));
                  }),
                ),
              ),
              const SizedBox(height: 10),
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                const Text('Total semaine', style: TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                Text('${driver.weekEarnings.toStringAsFixed(2)} EUR', style: const TextStyle(fontFamily: 'Syne', fontSize: 16, fontWeight: FontWeight.w700, color: AppColors.cyan)),
              ]),
            ])),
            GridView.count(
              shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
              crossAxisCount: 2, mainAxisSpacing: 10, crossAxisSpacing: 10, childAspectRatio: 1.8,
              children: [
                StatBox(value: '22 EUR/h', label: 'TAUX HORAIRE', valueColor: AppColors.yellow, delta: '↑ Top 15%'),
                StatBox(value: '34', label: 'LIVRAISONS/SEM', valueColor: AppColors.green, delta: '↑ +8%'),
              ],
            ),
            const SizedBox(height: 12),
            LDCard(child: Row(children: [
              const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Solde disponible', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w500)),
                Text('Virement auto lundi', style: TextStyle(fontSize: 11, color: AppColors.textSecondary)),
              ])),
              Text('${driver.weekEarnings.toStringAsFixed(2)} EUR', style: const TextStyle(fontFamily: 'Syne', fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.cyan)),
            ])),
            LDButton(label: 'Virement immediat (gratuit)', onTap: () {}),
            const SizedBox(height: 20),
            const Text('HISTORIQUE AUJOURD\'HUI', style: TextStyle(fontFamily: 'SpaceMono', fontSize: 10, color: AppColors.textSecondary)),
            const SizedBox(height: 10),
            ...[
              ['Bastille -> Opera', '10:03 · 17 min', '6,45'],
              ["Opera -> St-Lazare", '09:12 · 12 min', '5,20'],
              ['Chatelet -> Bastille', '08:35 · 20 min', '7,80'],
            ].map((e) => LDCard(child: Row(children: [
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(e[0], style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w500)),
                Text(e[1], style: const TextStyle(fontFamily: 'SpaceMono', fontSize: 10, color: AppColors.textSecondary)),
              ])),
              Text('+ ${e[2]} EUR', style: const TextStyle(fontFamily: 'Syne', fontSize: 15, fontWeight: FontWeight.w700, color: AppColors.green)),
            ]))),
          ]),
        ),
      ),
    );
  }
}
