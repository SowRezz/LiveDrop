
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../models/models.dart';
import '../../providers/providers.dart';
import '../../widgets/common/widgets.dart';

class DriverHomeScreen extends StatelessWidget {
  const DriverHomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final dp = context.watch<DriverProvider>();
    final driver = dp.driver ?? DriverModel.mock;

    return Scaffold(
      body: SafeArea(
        child: CustomScrollView(slivers: [
          SliverToBoxAdapter(child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('Livreur actif', style: TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                  Text(driver.fullName, style: const TextStyle(fontFamily: 'Syne', fontSize: 22, fontWeight: FontWeight.w700)),
                ]),
                const Spacer(),
                Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                  DriverStatusBadge(isOnline: dp.isOnline),
                  const SizedBox(height: 6),
                  GestureDetector(
                    onTap: dp.toggleOnline,
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      width: 48, height: 26,
                      decoration: BoxDecoration(
                        color: dp.isOnline ? AppColors.cyan.withOpacity(0.2) : AppColors.surface3,
                        borderRadius: BorderRadius.circular(13),
                        border: Border.all(color: dp.isOnline ? AppColors.cyan.withOpacity(0.5) : AppColors.border),
                      ),
                      child: AnimatedAlign(
                        duration: const Duration(milliseconds: 200),
                        alignment: dp.isOnline ? Alignment.centerRight : Alignment.centerLeft,
                        child: Container(width: 18, height: 18, margin: const EdgeInsets.symmetric(horizontal: 2),
                          decoration: BoxDecoration(shape: BoxShape.circle, color: dp.isOnline ? AppColors.cyan : AppColors.textTertiary)),
                      ),
                    ),
                  ),
                ]),
              ]),
              const SizedBox(height: 16),
              // Earnings
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [AppColors.cyan.withOpacity(0.08), AppColors.cyan.withOpacity(0.02)]),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: AppColors.cyan.withOpacity(0.2)),
                ),
                child: Column(children: [
                  Row(children: [
                    Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      const Text('GAINS AUJOURD\'HUI', style: TextStyle(fontFamily: 'SpaceMono', fontSize: 10, color: AppColors.textSecondary)),
                      Text('${driver.todayEarnings.toStringAsFixed(2)} EUR', style: const TextStyle(fontFamily: 'Syne', fontSize: 36, fontWeight: FontWeight.w800, color: AppColors.cyan)),
                      Text('${driver.todayDeliveries} livraisons', style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                    ]),
                    const Spacer(),
                    Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                      const Text('En ligne depuis', style: TextStyle(fontSize: 10, color: AppColors.textSecondary)),
                      const Text('3h 24m', style: TextStyle(fontFamily: 'Syne', fontSize: 16, fontWeight: FontWeight.w600)),
                      LDTag.green('${driver.rating} ★'),
                    ]),
                  ]),
                  const SizedBox(height: 12),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: EarningsPeriod.mockWeek.map((e) {
                      final mx = EarningsPeriod.mockWeek.map((x) => x.amount).reduce((a, b) => a > b ? a : b);
                      final f = e.amount / mx;
                      return Expanded(child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 2),
                        child: Container(
                          height: 40 * f,
                          decoration: BoxDecoration(
                            color: AppColors.cyan.withOpacity(f > 0.9 ? 1.0 : 0.3 + f * 0.2),
                            borderRadius: BorderRadius.circular(3),
                          ),
                        ),
                      ));
                    }).toList(),
                  ),
                ]),
              ),
              const SizedBox(height: 14),
              GridView.count(
                shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
                crossAxisCount: 2, mainAxisSpacing: 10, crossAxisSpacing: 10, childAspectRatio: 2.2,
                children: [
                  StatBox(value: '3h 24m', label: 'EN LIGNE', valueColor: AppColors.green),
                  StatBox(value: '${driver.currentStreak}🔥', label: 'STREAK', valueColor: AppColors.purple),
                ],
              ),
              const SizedBox(height: 20),
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                const Text('Missions disponibles', style: TextStyle(fontFamily: 'Syne', fontSize: 14, fontWeight: FontWeight.w600)),
                if (dp.availableMissions.isNotEmpty) LDTag.orange('${dp.availableMissions.length} missions'),
              ]),
              const SizedBox(height: 10),
            ]),
          )),
          if (!dp.isOnline)
            const SliverToBoxAdapter(child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: AlertBanner(message: 'Vous etes hors ligne. Activez pour recevoir des missions.', type: AlertType.warning),
            )),
          SliverList(delegate: SliverChildBuilderDelegate(
            (_, i) {
              if (i >= dp.availableMissions.length) return const SizedBox(height: 80);
              final m = dp.availableMissions[i];
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: GestureDetector(
                  onTap: () => context.go('/driver/mission/${m.deliveryId}'),
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 10),
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(color: AppColors.surface2, borderRadius: BorderRadius.circular(16), border: Border.all(color: AppColors.border)),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Row(children: [
                        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text('+ ${m.driverEarnings.toStringAsFixed(2)} EUR', style: const TextStyle(fontFamily: 'Syne', fontSize: 20, fontWeight: FontWeight.w800, color: AppColors.green)),
                          const Text('Apres commission 20%', style: TextStyle(fontSize: 10, color: AppColors.textSecondary)),
                        ]),
                        const Spacer(),
                        Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                          Text('${m.distanceToPickupKm.toStringAsFixed(1)} km', style: const TextStyle(fontFamily: 'Syne', fontSize: 15, fontWeight: FontWeight.w600, color: AppColors.cyan)),
                          Text('a ${(m.distanceToPickupKm * 3).round()} min', style: const TextStyle(fontSize: 10, color: AppColors.textSecondary)),
                        ]),
                      ]),
                      const SizedBox(height: 8),
                      Text('${m.pickupLocation.address} -> ${m.dropoffLocation.address}', style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                      const SizedBox(height: 8),
                      Wrap(spacing: 6, children: [
                        LDTag.yellow('${m.package.typeEmoji} ${m.package.typeLabel}'),
                        LDTag.cyan('~${m.estimatedMinutes} min'),
                        LDTag.cyan('${m.totalDistanceKm.toStringAsFixed(1)} km'),
                      ]),
                    ]),
                  ),
                ),
              );
            },
            childCount: dp.availableMissions.length + 1,
          )),
        ]),
      ),
    );
  }
}
