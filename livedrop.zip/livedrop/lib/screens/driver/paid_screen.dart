
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../models/models.dart';
import '../../providers/providers.dart';
import '../../widgets/common/widgets.dart';

class PaidScreen extends StatefulWidget {
  const PaidScreen({super.key});
  @override
  State<PaidScreen> createState() => _PaidState();
}

class _PaidState extends State<PaidScreen> with SingleTickerProviderStateMixin {
  late AnimationController _pop;
  late Animation<double> _popAnim;

  @override
  void initState() {
    super.initState();
    _pop = AnimationController(vsync: this, duration: const Duration(milliseconds: 500));
    _popAnim = CurvedAnimation(parent: _pop, curve: Curves.elasticOut);
    _pop.forward();
    // Credit driver
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<DriverProvider>().completeDelivery(rating: 4.9);
    });
  }
  @override
  void dispose() { _pop.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final dp = context.watch<DriverProvider>();
    final driver = dp.driver ?? DriverModel.mock;
    const earnings = 6.45;

    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Column(children: [
            const SizedBox(height: 32),
            ScaleTransition(
              scale: _popAnim,
              child: Container(
                width: 80, height: 80,
                decoration: BoxDecoration(shape: BoxShape.circle, color: AppColors.cyan.withOpacity(0.08), border: Border.all(color: AppColors.cyan, width: 2), boxShadow: [BoxShadow(color: AppColors.cyan.withOpacity(0.2), blurRadius: 20)]),
                child: const Center(child: Text('💰', style: TextStyle(fontSize: 34))),
              ),
            ),
            const SizedBox(height: 20),
            const Text('Livraison reussie!', style: TextStyle(fontFamily: 'Syne', fontSize: 24, fontWeight: FontWeight.w800)),
            const SizedBox(height: 6),
            const Text('Paiement credite sur votre compte', style: TextStyle(fontSize: 13, color: AppColors.textSecondary)),
            const SizedBox(height: 28),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [AppColors.cyan.withOpacity(0.08), AppColors.cyan.withOpacity(0.02)]),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppColors.cyan.withOpacity(0.2)),
              ),
              child: Row(children: [
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('CETTE LIVRAISON', style: TextStyle(fontFamily: 'SpaceMono', fontSize: 10, color: AppColors.textSecondary)),
                  Text('+ ${earnings.toStringAsFixed(2)} EUR', style: const TextStyle(fontFamily: 'Syne', fontSize: 32, fontWeight: FontWeight.w800, color: AppColors.cyan)),
                ]),
                const Spacer(),
                Container(
                  width: 50, height: 50,
                  decoration: BoxDecoration(shape: BoxShape.circle, color: AppColors.cyan.withOpacity(0.1), border: Border.all(color: AppColors.cyan)),
                  child: const Center(child: Icon(Icons.check, color: AppColors.cyan, size: 24)),
                ),
              ]),
            ),
            const SizedBox(height: 12),
            LDCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('DETAIL PAIEMENT', style: TextStyle(fontFamily: 'Syne', fontSize: 12, fontWeight: FontWeight.w600)),
              const SizedBox(height: 10),
              _r('Prix total client', '8,06 EUR'),
              _r('Commission LiveDrop (20%)', '- 1,61 EUR', c: AppColors.red),
              const Divider(color: AppColors.border),
              _r('Vos gains nets', '${earnings.toStringAsFixed(2)} EUR', c: AppColors.green, bold: true),
            ])),
            LDCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('RESUME MISSION', style: TextStyle(fontFamily: 'Syne', fontSize: 12, fontWeight: FontWeight.w600)),
              const SizedBox(height: 10),
              Row(children: [
                Expanded(child: _stat('17 min', 'Duree', AppColors.cyan)),
                Expanded(child: _stat('3.4 km', 'Distance', AppColors.yellow)),
                Expanded(child: _stat('22 EUR/h', 'Taux horaire', AppColors.green)),
              ]),
            ])),
            // Streak
            LDCard(
              color: AppColors.purple.withOpacity(0.06),
              borderColor: AppColors.purple.withOpacity(0.2),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('Streak x7 🔥', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w500)),
                    Text('7 livraisons consecutives', style: TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                  ])),
                  LDTag.purple('Bonus +10%'),
                ]),
                const SizedBox(height: 10),
                LDProgressBar(value: 0.7, color: AppColors.purple),
                const SizedBox(height: 4),
                const Text('3 livraisons de plus -> Bonus x2', style: TextStyle(fontFamily: 'SpaceMono', fontSize: 10, color: AppColors.textTertiary)),
              ]),
            ),
            const SizedBox(height: 4),
            LDButton(label: 'Chercher une mission ->', onTap: () => context.go('/driver')),
            const SizedBox(height: 8),
            LDButton(label: 'Voir mes gains', outline: true, onTap: () => context.go('/driver/earnings')),
            const SizedBox(height: 20),
          ]),
        ),
      ),
    );
  }

  Widget _r(String l, String v, {Color? c, bool bold = false}) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 5),
    child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Text(l, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
      Text(v, style: TextStyle(fontFamily: bold ? 'Syne' : null, fontSize: bold ? 16 : 12, fontWeight: bold ? FontWeight.w700 : FontWeight.normal, color: c ?? AppColors.textPrimary)),
    ]),
  );

  Widget _stat(String val, String lbl, Color c) => Column(children: [
    Text(val, style: TextStyle(fontFamily: 'Syne', fontSize: 16, fontWeight: FontWeight.w700, color: c)),
    Text(lbl, style: const TextStyle(fontSize: 10, color: AppColors.textSecondary)),
  ]);
}
