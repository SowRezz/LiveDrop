
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/theme/app_theme.dart';

class DriverShell extends StatelessWidget {
  final Widget child;
  const DriverShell({super.key, required this.child});

  int _idx(BuildContext context) {
    final loc = GoRouterState.of(context).matchedLocation;
    if (loc.startsWith('/driver/earnings')) return 1;
    if (loc.startsWith('/driver/profile')) return 2;
    return 0;
  }

  @override
  Widget build(BuildContext context) {
    final idx = _idx(context);
    return Scaffold(
      body: child,
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(border: Border(top: BorderSide(color: AppColors.border)), color: AppColors.surface1),
        child: SafeArea(
          child: Row(children: [
            _ni(context, Icons.map_outlined, 'Carte', idx == 0, '/driver'),
            _ni(context, Icons.attach_money_rounded, 'Gains', idx == 1, '/driver/earnings'),
            _ni(context, Icons.person_outline, 'Profil', idx == 2, '/driver/profile'),
          ]),
        ),
      ),
    );
  }

  Widget _ni(BuildContext ctx, IconData icon, String label, bool active, String route) {
    return Expanded(
      child: GestureDetector(
        onTap: () => ctx.go(route),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 10),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(icon, size: 24, color: active ? AppColors.cyan : AppColors.textTertiary),
            const SizedBox(height: 3),
            Text(label, style: TextStyle(fontFamily: 'SpaceMono', fontSize: 9, color: active ? AppColors.cyan : AppColors.textTertiary)),
          ]),
        ),
      ),
    );
  }
}
