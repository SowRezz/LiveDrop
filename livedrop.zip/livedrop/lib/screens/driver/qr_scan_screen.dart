
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../models/models.dart';
import '../../providers/providers.dart';
import '../../widgets/common/widgets.dart';

class QRScanScreen extends StatefulWidget {
  final bool isPickup;
  const QRScanScreen({super.key, required this.isPickup});
  @override
  State<QRScanScreen> createState() => _QRState();
}

class _QRState extends State<QRScanScreen> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scan;
  bool _photoTaken = false;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(seconds: 2))..repeat(reverse: true);
    _scan = Tween<double>(begin: 0.05, end: 0.9).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut));
  }
  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final dp = context.watch<DriverProvider>();
    final m = dp.activeMission ?? MissionModel.mockList.first;

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(icon: const Icon(Icons.arrow_back, size: 20), onPressed: () => context.go(widget.isPickup ? '/driver/navigate/a' : '/driver/navigate/b')),
        title: Text(widget.isPickup ? 'Scanner — Point A' : 'Confirmer livraison', style: const TextStyle(fontFamily: 'Syne', fontSize: 17, fontWeight: FontWeight.w700)),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(children: [
            Text(widget.isPickup ? 'Demandez le QR code de collecte au client' : 'Montrez ce QR au destinataire', textAlign: TextAlign.center, style: const TextStyle(fontSize: 13, color: AppColors.textSecondary)),
            const SizedBox(height: 24),
            widget.isPickup
              ? _scanner()
              : Container(
                  width: 160, height: 160,
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), boxShadow: [BoxShadow(color: AppColors.cyan.withOpacity(0.2), blurRadius: 20)]),
                  padding: const EdgeInsets.all(12),
                  child: _qrGrid(),
                ),
            const SizedBox(height: 8),
            Text('LVR-2024-8472 · ${widget.isPickup ? "PICKUP" : "DROP-OFF"}', style: const TextStyle(fontFamily: 'SpaceMono', fontSize: 10, color: AppColors.textSecondary)),
            const SizedBox(height: 16),
            LDCard(child: Column(children: [
              _info('Type', '${m.package.typeEmoji} ${m.package.typeLabel}'),
              const Divider(color: AppColors.border),
              _info('Destination', m.dropoffLocation.address),
              if (widget.isPickup) ...[
                const Divider(color: AppColors.border),
                _info('Valeur declaree', '150 EUR'),
              ],
            ])),
            if (!widget.isPickup && !_photoTaken) ...[
              AlertBanner(message: 'Prenez une photo du colis depose comme preuve obligatoire', type: AlertType.warning),
              GestureDetector(
                onTap: () => setState(() => _photoTaken = true),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  height: 100,
                  margin: const EdgeInsets.only(bottom: 14),
                  decoration: BoxDecoration(
                    color: _photoTaken ? AppColors.green.withOpacity(0.06) : AppColors.surface2,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: _photoTaken ? AppColors.green.withOpacity(0.4) : AppColors.cyan.withOpacity(0.2), width: 1.5),
                  ),
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Text(_photoTaken ? '✅' : '📷', style: const TextStyle(fontSize: 28)),
                    Text(_photoTaken ? 'Photo prise — GPS confirme' : 'Prendre photo (obligatoire)', style: TextStyle(fontSize: 12, color: _photoTaken ? AppColors.green : AppColors.textSecondary)),
                  ]),
                ),
              ),
            ],
            if (widget.isPickup)
              const AlertBanner(message: 'Verifiez que le colis correspond avant de confirmer', type: AlertType.info),
            const SizedBox(height: 4),
            LDButton(
              label: widget.isPickup ? 'Colis recupere — En route ->' : 'Livraison confirmee ->',
              onTap: !widget.isPickup && !_photoTaken
                  ? () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Prenez une photo du colis d\'abord'), backgroundColor: AppColors.orange))
                  : () => context.go('/driver/paid'),
            ),
          ]),
        ),
      ),
    );
  }

  Widget _scanner() {
    return SizedBox(
      width: 200, height: 200,
      child: Stack(children: [
        Container(decoration: BoxDecoration(color: Colors.black87, borderRadius: BorderRadius.circular(14))),
        // QR placeholder
        Center(child: Container(width: 120, height: 120, color: Colors.white, padding: const EdgeInsets.all(8), child: _qrGrid())),
        // Corners
        ..._corners(),
        // Scan line
        AnimatedBuilder(
          animation: _scan,
          builder: (_, __) => Positioned(
            top: 200 * _scan.value,
            left: 10, right: 10,
            child: Container(height: 2, decoration: BoxDecoration(gradient: LinearGradient(colors: [Colors.transparent, AppColors.cyan, Colors.transparent]))),
          ),
        ),
      ]),
    );
  }

  List<Widget> _corners() {
    const s = 18.0;
    const t = 2.5;
    final c = AppColors.cyan;
    return [
      Positioned(top: 0, left: 0, child: _corner(true, true, s, t, c)),
      Positioned(top: 0, right: 0, child: _corner(true, false, s, t, c)),
      Positioned(bottom: 0, left: 0, child: _corner(false, true, s, t, c)),
      Positioned(bottom: 0, right: 0, child: _corner(false, false, s, t, c)),
    ];
  }

  Widget _corner(bool top, bool left, double s, double t, Color c) => SizedBox(
    width: s, height: s,
    child: CustomPaint(painter: _CornerPainter(top: top, left: left, color: c, thickness: t)),
  );

  Widget _qrGrid() {
    final pattern = [
      [1,1,1,0,1,0,1], [1,0,1,0,1,1,1], [1,0,1,1,0,1,0],
      [0,1,0,1,1,0,1], [1,1,1,0,1,1,0], [0,1,0,1,0,1,1], [1,1,0,1,1,0,1],
    ];
    return GridView.count(
      crossAxisCount: 7, mainAxisSpacing: 1.5, crossAxisSpacing: 1.5,
      physics: const NeverScrollableScrollPhysics(),
      children: pattern.expand((row) => row.map((v) => Container(
        decoration: BoxDecoration(color: v == 1 ? const Color(0xFF050A14) : Colors.white, borderRadius: BorderRadius.circular(1.5)),
      ))).toList(),
    );
  }

  Widget _info(String l, String v) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 6),
    child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Text(l, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
      Text(v, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w500)),
    ]),
  );
}

class _CornerPainter extends CustomPainter {
  final bool top, left;
  final Color color;
  final double thickness;
  const _CornerPainter({required this.top, required this.left, required this.color, required this.thickness});
  @override
  void paint(Canvas canvas, Size s) {
    final p = Paint()..color = color..strokeWidth = thickness..style = PaintingStyle.stroke..strokeCap = StrokeCap.square;
    final x = left ? 0.0 : s.width;
    final y = top ? 0.0 : s.height;
    final dx = left ? s.width : -s.width;
    final dy = top ? s.height : -s.height;
    canvas.drawLine(Offset(x, y), Offset(x + dx, y), p);
    canvas.drawLine(Offset(x, y), Offset(x, y + dy), p);
  }
  @override
  bool shouldRepaint(_) => false;
}
