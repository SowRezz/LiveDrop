import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../providers/providers.dart';
import '../../widgets/common/widgets.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final _emailCtrl = TextEditingController(text: 'marie@livedrop.fr');
  final _passCtrl = TextEditingController(text: 'password123');
  bool _obscure = true;

  @override
  void dispose() {
    _emailCtrl.dispose();
    _passCtrl.dispose();
    super.dispose();
  }

  Future<void> _login() async {
    if (!_formKey.currentState!.validate()) return;
    final auth = context.read<AuthProvider>();
    final ok = await auth.login(_emailCtrl.text.trim(), _passCtrl.text);
    if (!mounted) return;
    if (ok) {
      context.go(auth.isDriver ? '/driver' : '/client');
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(auth.error ?? 'Erreur de connexion'),
          backgroundColor: AppColors.red));
    }
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                GestureDetector(
                  onTap: () => context.go('/splash'),
                  child: Container(
                    width: 36,
                    height: 36,
                    decoration: BoxDecoration(
                        color: AppColors.surface2,
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(color: AppColors.border)),
                    child: const Icon(Icons.arrow_back,
                        size: 18, color: AppColors.textPrimary),
                  ),
                ),
                const SizedBox(height: 28),
                const Text('Connexion',
                    style: TextStyle(
                        fontFamily: 'Syne',
                        fontSize: 28,
                        fontWeight: FontWeight.w700)),
                const SizedBox(height: 4),
                const Text('Bon retour sur LiveDrop',
                    style: TextStyle(
                        color: AppColors.textSecondary, fontSize: 13)),
                const SizedBox(height: 28),
                LDInput(
                  label: 'EMAIL',
                  controller: _emailCtrl,
                  keyboardType: TextInputType.emailAddress,
                  validator: (v) =>
                      (v == null || !v.contains('@')) ? 'Email invalide' : null,
                ),
                LDInput(
                  label: 'MOT DE PASSE',
                  controller: _passCtrl,
                  obscureText: _obscure,
                  suffix: IconButton(
                    icon: Icon(
                        _obscure
                            ? Icons.visibility_outlined
                            : Icons.visibility_off_outlined,
                        color: AppColors.textSecondary,
                        size: 18),
                    onPressed: () => setState(() => _obscure = !_obscure),
                  ),
                  validator: (v) =>
                      (v == null || v.length < 6) ? 'Min. 6 caractères' : null,
                ),
                Align(
                  alignment: Alignment.centerRight,
                  child: Text('Mot de passe oublié ?',
                      style: const TextStyle(
                          fontSize: 12, color: AppColors.cyan)),
                ),
                const SizedBox(height: 24),
                LDButton(
                    label: 'Se connecter',
                    color: AppColors.yellow,
                    isLoading: auth.isLoading,
                    onTap: _login),
                const SizedBox(height: 10),
                Row(children: [
                  Expanded(
                    child: LDButton(
                        label: '👤 Demo Client',
                        outline: true,
                        onTap: () {
                          context.read<AuthProvider>().mockLoginAsClient();
                          context.go('/client');
                        }),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: LDButton(
                        label: '🛵 Demo Livreur',
                        outline: true,
                        onTap: () {
                          context.read<AuthProvider>().mockLoginAsDriver();
                          context.go('/driver');
                        }),
                  ),
                ]),
                const LDDivider(label: 'OU'),
                LDButton(
                    label: '🍎  Continuer avec Apple', outline: true),
                const SizedBox(height: 8),
                LDButton(
                    label: '🔵  Continuer avec Google', outline: true),
                const SizedBox(height: 28),
                Center(
                  child: GestureDetector(
                    onTap: () => context.go('/auth/register'),
                    child: const Text.rich(TextSpan(
                      style: TextStyle(
                          fontSize: 13, color: AppColors.textSecondary),
                      children: [
                        TextSpan(text: 'Pas encore de compte ? '),
                        TextSpan(
                            text: "S'inscrire",
                            style: TextStyle(
                                color: AppColors.yellow,
                                fontWeight: FontWeight.w600)),
                      ],
                    )),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
