import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/theme/app_theme.dart';
import '../../widgets/common/widgets.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});
  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final PageController _pageCtrl = PageController();
  int _current = 0;

  final List<Map<String, String>> _pages = [
    {
      'icon': '📦',
      'title': "Envoyez n'importe quoi",
      'body':
          "Colis, repas, meubles ou documents. Nos livreurs gèrent tout en moins de 30 minutes."
    },
    {
      'icon': '📍',
      'title': 'Suivi GPS en temps réel',
      'body':
          "Suivez votre colis à la minute près sur la carte. Contactez directement votre livreur."
    },
    {
      'icon': '💳',
      'title': 'Paiement 100% sécurisé',
      'body':
          "Stripe Connect protège votre argent jusqu'à confirmation de livraison."
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Align(
              alignment: Alignment.topRight,
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: GestureDetector(
                  onTap: () => context.go('/auth/login'),
                  child: const Text('Passer',
                      style: TextStyle(
                          color: AppColors.textSecondary, fontSize: 13)),
                ),
              ),
            ),
            Expanded(
              child: PageView.builder(
                controller: _pageCtrl,
                onPageChanged: (i) => setState(() => _current = i),
                itemCount: _pages.length,
                itemBuilder: (_, i) => Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 32),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(_pages[i]['icon']!,
                          style: const TextStyle(fontSize: 72)),
                      const SizedBox(height: 28),
                      Text(
                        _pages[i]['title']!,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                            fontFamily: 'Syne',
                            fontSize: 24,
                            fontWeight: FontWeight.w700,
                            color: AppColors.textPrimary),
                      ),
                      const SizedBox(height: 12),
                      Text(
                        _pages[i]['body']!,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                            fontSize: 14,
                            color: AppColors.textSecondary,
                            height: 1.6),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(
                  _pages.length,
                  (i) => AnimatedContainer(
                        duration: const Duration(milliseconds: 250),
                        margin: const EdgeInsets.symmetric(horizontal: 3),
                        width: _current == i ? 20 : 6,
                        height: 6,
                        decoration: BoxDecoration(
                          color: _current == i
                              ? AppColors.cyan
                              : AppColors.surface3,
                          borderRadius: BorderRadius.circular(3),
                        ),
                      )),
            ),
            const SizedBox(height: 32),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 28),
              child: Column(
                children: [
                  LDButton(
                    label: _current < 2 ? 'Suivant →' : "C'est parti →",
                    color: AppColors.yellow,
                    onTap: () {
                      if (_current < 2) {
                        _pageCtrl.nextPage(
                            duration: const Duration(milliseconds: 300),
                            curve: Curves.easeInOut);
                      } else {
                        context.go('/auth/login');
                      }
                    },
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
