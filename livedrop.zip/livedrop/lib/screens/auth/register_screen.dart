import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../models/models.dart';
import '../../providers/providers.dart';
import '../../widgets/common/widgets.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});
  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _formKey = GlobalKey<FormState>();
  final _firstCtrl = TextEditingController();
  final _lastCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  UserRole _role = UserRole.client;

  @override
  void dispose() {
    _firstCtrl.dispose();
    _lastCtrl.dispose();
    _emailCtrl.dispose();
    _phoneCtrl.dispose();
    _passCtrl.dispose();
    super.dispose();
  }

  Future<void> _register() async {
    if (!_formKey.currentState!.validate()) return;
    final auth = context.read<AuthProvider>();
    final ok = await auth.register(
      firstName: _firstCtrl.text.trim(),
      lastName: _lastCtrl.text.trim(),
      email: _emailCtrl.text.trim(),
      phone: _phoneCtrl.text.trim(),
      password: _passCtrl.text,
      role: _role,
    );
    if (!mounted) return;
    if (ok) context.go(_role == UserRole.driver ? '/driver' : '/client');
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                GestureDetector(
                  onTap: () => context.go('/auth/login'),
                  child: Container(
                    width: 36,
                    height: 36,
                    decoration: BoxDecoration(
                        color: AppColors.surface2,
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(color: AppColors.border)),
                    child: const Icon(Icons.arrow_back,
                        size: 18, color: AppColors.textPrimary),
                  ),
                ),
                const SizedBox(height: 24),
                const Text('Créer un compte',
                    style: TextStyle(
                        fontFamily: 'Syne',
                        fontSize: 24,
                        fontWeight: FontWeight.w700)),
                const SizedBox(height: 20),
                // Role selector
                Container(
                  padding: const EdgeInsets.all(4),
                  decoration: BoxDecoration(
                      color: AppColors.surface2,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: AppColors.border)),
                  child: Row(children: [
                    _roleBtn(UserRole.client, '📦 Client', "J'envoie des colis"),
                    _roleBtn(UserRole.driver, '🛵 Livreur', 'Je livre des colis'),
                  ]),
                ),
                const SizedBox(height: 20),
                Row(children: [
                  Expanded(
                      child: LDInput(
                          label: 'PRÉNOM',
                          controller: _firstCtrl,
                          validator: (v) => v!.isEmpty ? 'Requis' : null)),
                  const SizedBox(width: 10),
                  Expanded(
                      child: LDInput(
                          label: 'NOM',
                          controller: _lastCtrl,
                          validator: (v) => v!.isEmpty ? 'Requis' : null)),
                ]),
                LDInput(
                  label: 'EMAIL',
                  controller: _emailCtrl,
                  keyboardType: TextInputType.emailAddress,
                  validator: (v) =>
                      (v == null || !v.contains('@')) ? 'Email invalide' : null,
                ),
                LDInput(
                  label: 'TÉLÉPHONE',
                  controller: _phoneCtrl,
                  keyboardType: TextInputType.phone,
                  hint: '+33 6 XX XX XX XX',
                  validator: (v) => v!.isEmpty ? 'Requis' : null,
                ),
                LDInput(
                  label: 'MOT DE PASSE',
                  controller: _passCtrl,
                  obscureText: true,
                  validator: (v) =>
                      (v == null || v.length < 8) ? 'Min. 8 caractères' : null,
                ),
                if (_role == UserRole.driver)
                  const AlertBanner(
                      message:
                          '📄 Vos documents d\'identité et de véhicule seront vérifiés avant activation.',
                      type: AlertType.info),
                const AlertBanner(
                    message:
                        '📱 Un SMS de vérification sera envoyé à votre numéro',
                    type: AlertType.info),
                LDButton(
                    label: 'Créer mon compte →',
                    color: AppColors.yellow,
                    isLoading: auth.isLoading,
                    onTap: _register),
                const SizedBox(height: 16),
                const Center(
                  child: Text(
                    'En créant un compte, vous acceptez nos CGU et Politique de confidentialité',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        fontSize: 11,
                        color: AppColors.textTertiary,
                        height: 1.5),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _roleBtn(UserRole role, String title, String sub) {
    final sel = _role == role;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => _role = role),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: sel ? AppColors.cyan.withOpacity(0.12) : Colors.transparent,
            borderRadius: BorderRadius.circular(8),
            border: sel
                ? Border.all(color: AppColors.cyan.withOpacity(0.4))
                : null,
          ),
          child: Column(children: [
            Text(title,
                style: TextStyle(
                    fontWeight: FontWeight.w600,
                    color: sel ? AppColors.cyan : AppColors.textSecondary,
                    fontSize: 13)),
            Text(sub,
                style: const TextStyle(
                    fontSize: 10, color: AppColors.textTertiary)),
          ]),
        ),
      ),
    );
  }
}
