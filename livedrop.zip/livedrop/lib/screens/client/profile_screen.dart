
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../providers/providers.dart';
import '../../widgets/common/widgets.dart';

class ClientProfileScreen extends StatelessWidget {
  const ClientProfileScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final delivery = context.watch<DeliveryProvider>();
    final user = auth.user!;
    final total = delivery.history.fold(0.0, (s, d) => s + d.pricing.total);
    return Scaffold(
      appBar: AppBar(title: const Text('Profil', style: TextStyle(fontFamily: 'Syne', fontSize: 20, fontWeight: FontWeight.w700))),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(children: [
            CircleAvatar(radius: 38, backgroundColor: AppColors.surface3,
              child: Text(user.firstName[0], style: const TextStyle(fontFamily: 'Syne', fontSize: 32, fontWeight: FontWeight.w800, color: AppColors.textPrimary))),
            const SizedBox(height: 12),
            Text(user.fullName, style: const TextStyle(fontFamily: 'Syne', fontSize: 20, fontWeight: FontWeight.w700)),
            Text(user.email, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
            if (user.isVerified) ...[const SizedBox(height: 6), LDTag.green('Compte verifie')],
            const SizedBox(height: 24),
            GridView.count(
              shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
              crossAxisCount: 2, mainAxisSpacing: 10, crossAxisSpacing: 10, childAspectRatio: 1.8,
              children: [
                StatBox(value: '${user.totalDeliveries}', label: 'LIVRAISONS', valueColor: AppColors.yellow),
                StatBox(value: '${total.toStringAsFixed(0)} EUR', label: 'TOTAL DEPENSE', valueColor: AppColors.cyan),
                StatBox(value: '${user.rating} ★', label: 'MA NOTE', valueColor: AppColors.green),
                StatBox(value: '${user.walletBalance.toStringAsFixed(2)} EUR', label: 'WALLET', valueColor: AppColors.purple),
              ],
            ),
            const SizedBox(height: 20),
            Container(
              decoration: BoxDecoration(color: AppColors.surface2, borderRadius: BorderRadius.circular(16), border: Border.all(color: AppColors.border)),
              child: Column(children: [
                _mi('📍', 'Adresses enregistrees'),
                _mi('💳', 'Modes de paiement'),
                _mi('🎁', 'Parrainage - Gagnez 5 EUR', color: AppColors.green),
                _mi('🔔', 'Notifications'),
                _mi('🔒', 'Securite'),
                _mi('❓', 'Aide et support'),
              ]),
            ),
            const SizedBox(height: 12),
            LDButton(label: 'Se deconnecter', outline: true, textColor: AppColors.red, onTap: () { auth.logout(); context.go('/splash'); }),
          ]),
        ),
      ),
    );
  }
  Widget _mi(String ico, String label, {Color? color}) => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
    child: Row(children: [
      Text(ico, style: const TextStyle(fontSize: 18)),
      const SizedBox(width: 12),
      Expanded(child: Text(label, style: TextStyle(fontSize: 13, color: color ?? AppColors.textPrimary))),
      Icon(Icons.chevron_right, size: 18, color: color ?? AppColors.textTertiary),
    ]),
  );
}
