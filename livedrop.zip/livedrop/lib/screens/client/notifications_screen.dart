
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../providers/providers.dart';
import '../../widgets/common/widgets.dart';

class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final notifs = context.watch<NotificationProvider>();
    return Scaffold(
      appBar: AppBar(
        title: const Text('Notifications', style: TextStyle(fontFamily: 'Syne', fontSize: 20, fontWeight: FontWeight.w700)),
        actions: [TextButton(onPressed: notifs.markAllRead, child: const Text('Tout lire', style: TextStyle(fontSize: 12, color: AppColors.cyan)))],
      ),
      body: SafeArea(
        child: ListView.builder(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          itemCount: notifs.notifications.length,
          itemBuilder: (_, i) {
            final n = notifs.notifications[i];
            return LDCard(
              onTap: n.routeTo != null ? () => context.go(n.routeTo!) : null,
              borderColor: !n.isRead ? AppColors.cyan.withOpacity(0.2) : null,
              child: Row(children: [
                Text(_ico(n.type), style: const TextStyle(fontSize: 22)),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(n.title, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w500, color: !n.isRead ? AppColors.textPrimary : AppColors.textSecondary)),
                  Text(n.body, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary, height: 1.4)),
                ])),
                if (!n.isRead) Container(width: 8, height: 8, decoration: const BoxDecoration(color: AppColors.cyan, shape: BoxShape.circle)),
              ]),
            );
          },
        ),
      ),
    );
  }
  String _ico(String t) {
    switch(t) {
      case 'driver_en_route': return '🛵';
      case 'payment_confirmed': return '✅';
      case 'driver_found': return '🎉';
      case 'promo': return '💰';
      default: return '📢';
    }
  }
}
