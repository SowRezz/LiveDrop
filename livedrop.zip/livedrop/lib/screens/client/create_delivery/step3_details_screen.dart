
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../../core/theme/app_theme.dart';
import '../../../models/models.dart';
import '../../../providers/providers.dart';
import '../../../widgets/common/widgets.dart';

class Step3DetailsScreen extends StatefulWidget {
  const Step3DetailsScreen({super.key});
  @override
  State<Step3DetailsScreen> createState() => _Step3State();
}

class _Step3State extends State<Step3DetailsScreen> {
  final _descCtrl = TextEditingController();
  final _instrCtrl = TextEditingController();
  final _valueCtrl = TextEditingController(text: '150');
  final _weightCtrl = TextEditingController(text: '3.5');
  final _nameCtrl = TextEditingController(text: 'Jean Martin');
  final _phoneCtrl = TextEditingController(text: '+33 6 98 76 54 32');
  bool _photoTaken = false;

  @override
  void dispose() {
    _descCtrl.dispose(); _instrCtrl.dispose(); _valueCtrl.dispose();
    _weightCtrl.dispose(); _nameCtrl.dispose(); _phoneCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(icon: const Icon(Icons.arrow_back, size: 20), onPressed: () => context.go('/client/create/step2')),
        title: const Text('Informations', style: TextStyle(fontFamily: 'Syne', fontSize: 17, fontWeight: FontWeight.w700)),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              DeliveryProgressSteps(currentStep: 2),
              const SizedBox(height: 24),
              LDInput(label: 'DESCRIPTION DU COLIS', controller: _descCtrl, hint: 'Ex: Boite en carton, contient des livres...', maxLines: 3),
              LDInput(label: 'INSTRUCTIONS POUR LE LIVREUR', controller: _instrCtrl, hint: 'Ex: Code porte B465, 3e etage...', maxLines: 2),
              Row(children: [
                Expanded(child: LDInput(label: 'VALEUR (EUR)', controller: _valueCtrl, keyboardType: TextInputType.number)),
                const SizedBox(width: 10),
                Expanded(child: LDInput(label: 'POIDS (KG)', controller: _weightCtrl, keyboardType: TextInputType.number)),
              ]),
              const Text('PHOTO DU COLIS', style: TextStyle(fontFamily: 'SpaceMono', fontSize: 10, color: AppColors.textSecondary)),
              const SizedBox(height: 8),
              GestureDetector(
                onTap: () => setState(() => _photoTaken = true),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  height: 110,
                  margin: const EdgeInsets.only(bottom: 14),
                  decoration: BoxDecoration(
                    color: _photoTaken ? AppColors.green.withOpacity(0.06) : AppColors.surface2,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: _photoTaken ? AppColors.green.withOpacity(0.4) : AppColors.cyan.withOpacity(0.2), width: 1.5),
                  ),
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Text(_photoTaken ? '✅' : '📷', style: const TextStyle(fontSize: 28)),
                    const SizedBox(height: 6),
                    Text(_photoTaken ? 'Photo prise' : 'Prendre une photo', style: TextStyle(fontSize: 12, color: _photoTaken ? AppColors.green : AppColors.textSecondary)),
                    const Text('Recommande pour les litiges', style: TextStyle(fontSize: 10, color: AppColors.textTertiary)),
                  ]),
                ),
              ),
              const Text('CONTACT DESTINATAIRE', style: TextStyle(fontFamily: 'SpaceMono', fontSize: 10, color: AppColors.textSecondary)),
              const SizedBox(height: 10),
              Row(children: [
                Expanded(child: LDInput(label: 'NOM', controller: _nameCtrl)),
                const SizedBox(width: 10),
                Expanded(child: LDInput(label: 'TELEPHONE', controller: _phoneCtrl, keyboardType: TextInputType.phone)),
              ]),
              LDButton(
                label: 'Voir le prix ->',
                color: AppColors.yellow,
                onTap: () {
                  context.read<DeliveryProvider>().setRecipient(RecipientModel(name: _nameCtrl.text, phone: _phoneCtrl.text));
                  context.go('/client/create/step4');
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
