
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../../core/theme/app_theme.dart';
import '../../../models/models.dart';
import '../../../providers/providers.dart';
import '../../../widgets/common/widgets.dart';

class Step1AddressScreen extends StatefulWidget {
  const Step1AddressScreen({super.key});
  @override
  State<Step1AddressScreen> createState() => _Step1State();
}

class _Step1State extends State<Step1AddressScreen> {
  final _pickupCtrl = TextEditingController(text: '12 Rue de la Bastille, Paris 75004');
  final _dropCtrl = TextEditingController(text: "8 Avenue de l'Opera, Paris 75001");
  bool _isImmediate = true;

  @override
  void dispose() { _pickupCtrl.dispose(); _dropCtrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(icon: const Icon(Icons.arrow_back, size: 20), onPressed: () => context.go('/client')),
        title: const Text('Nouvelle livraison', style: TextStyle(fontFamily: 'Syne', fontSize: 17, fontWeight: FontWeight.w700)),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              DeliveryProgressSteps(currentStep: 0),
              const SizedBox(height: 24),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppColors.surface2, borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: AppColors.cyan.withOpacity(0.15)),
                ),
                child: Column(children: [
                  Row(
                    children: [
                      Column(children: [
                        Container(width: 10, height: 10, decoration: const BoxDecoration(color: AppColors.yellow, shape: BoxShape.circle)),
                        Container(width: 1, height: 44, color: AppColors.border),
                        Container(width: 10, height: 10, decoration: BoxDecoration(color: AppColors.cyan, borderRadius: BorderRadius.circular(2))),
                      ]),
                      const SizedBox(width: 12),
                      Expanded(child: Column(children: [
                        TextField(
                          controller: _pickupCtrl,
                          style: const TextStyle(fontSize: 13, color: AppColors.textPrimary),
                          decoration: const InputDecoration(hintText: 'Adresse de depart', border: InputBorder.none, contentPadding: EdgeInsets.symmetric(vertical: 10)),
                        ),
                        const Divider(color: AppColors.border),
                        TextField(
                          controller: _dropCtrl,
                          style: const TextStyle(fontSize: 13, color: AppColors.textPrimary),
                          decoration: const InputDecoration(hintText: "Adresse d'arrivee", border: InputBorder.none, contentPadding: EdgeInsets.symmetric(vertical: 10)),
                        ),
                      ])),
                    ],
                  ),
                  const Divider(color: AppColors.border),
                  Row(children: [LDTag.cyan('3.2 km'), const SizedBox(width: 6), LDTag.green('~18 min')]),
                ]),
              ),
              const SizedBox(height: 12),
              Wrap(spacing: 8, runSpacing: 8, children: [
                _shortcut('Ma position'), _shortcut('Domicile'), _shortcut('Bureau'),
              ]),
              const SizedBox(height: 20),
              LDCard(
                child: Row(children: [
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
                    Text('Livraison immediate', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w500)),
                    Text('Livreur disponible en 10-20 min', style: TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                  ])),
                  GestureDetector(
                    onTap: () => setState(() => _isImmediate = !_isImmediate),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      width: 48, height: 26,
                      decoration: BoxDecoration(
                        color: _isImmediate ? AppColors.yellow.withOpacity(0.2) : AppColors.surface3,
                        borderRadius: BorderRadius.circular(13),
                        border: Border.all(color: _isImmediate ? AppColors.yellow.withOpacity(0.5) : AppColors.border),
                      ),
                      child: AnimatedAlign(
                        duration: const Duration(milliseconds: 200),
                        alignment: _isImmediate ? Alignment.centerRight : Alignment.centerLeft,
                        child: Container(
                          width: 18, height: 18, margin: const EdgeInsets.symmetric(horizontal: 2),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: _isImmediate ? AppColors.yellow : AppColors.textTertiary,
                          ),
                        ),
                      ),
                    ),
                  ),
                ]),
              ),
              if (!_isImmediate)
                LDInput(label: 'PLANIFIER POUR LE', keyboardType: TextInputType.datetime, hint: 'JJ/MM/AAAA HH:MM'),
              const SizedBox(height: 8),
              LDButton(
                label: 'Continuer -> Type de colis',
                color: AppColors.yellow,
                onTap: () {
                  context.read<DeliveryProvider>().setPickupLocation(LocationModel.bastille);
                  context.read<DeliveryProvider>().setDropoffLocation(LocationModel.opera);
                  context.go('/client/create/step2');
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _shortcut(String label) => GestureDetector(
    onTap: () {},
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(color: AppColors.surface3, borderRadius: BorderRadius.circular(6), border: Border.all(color: AppColors.border)),
      child: Text(label, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
    ),
  );
}
