
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../../core/theme/app_theme.dart';
import '../../../models/models.dart';
import '../../../providers/providers.dart';
import '../../../widgets/common/widgets.dart';

class Step2PackageScreen extends StatefulWidget {
  const Step2PackageScreen({super.key});
  @override
  State<Step2PackageScreen> createState() => _Step2State();
}

class _Step2State extends State<Step2PackageScreen> {
  PackageType _type = PackageType.parcel;
  PackageSize _size = PackageSize.medium;
  bool _isFragile = false;
  bool _isInsured = true;

  @override
  Widget build(BuildContext context) {
    final types = [
      {'t': PackageType.parcel, 'e': '📦', 'l': 'Colis'},
      {'t': PackageType.food, 'e': '🍔', 'l': 'Nourriture'},
      {'t': PackageType.furniture, 'e': '🛋️', 'l': 'Meuble'},
      {'t': PackageType.document, 'e': '📄', 'l': 'Document'},
      {'t': PackageType.medicine, 'e': '💊', 'l': 'Medicament'},
      {'t': PackageType.flowers, 'e': '🌸', 'l': 'Fleurs'},
    ];
    final sizes = [
      {'s': PackageSize.small, 'e': '✉️', 'l': 'Petit', 'k': '< 2 kg'},
      {'s': PackageSize.medium, 'e': '📦', 'l': 'Moyen', 'k': '< 10 kg'},
      {'s': PackageSize.large, 'e': '🗃️', 'l': 'Grand', 'k': '< 30 kg'},
      {'s': PackageSize.xxl, 'e': '🛋️', 'l': 'XXL', 'k': '> 30 kg'},
    ];
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(icon: const Icon(Icons.arrow_back, size: 20), onPressed: () => context.go('/client/create/step1')),
        title: const Text('Type de colis', style: TextStyle(fontFamily: 'Syne', fontSize: 17, fontWeight: FontWeight.w700)),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              DeliveryProgressSteps(currentStep: 1),
              const SizedBox(height: 24),
              const Text('CATEGORIE', style: TextStyle(fontFamily: 'SpaceMono', fontSize: 10, color: AppColors.textSecondary)),
              const SizedBox(height: 10),
              GridView.count(
                shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
                crossAxisCount: 3, mainAxisSpacing: 8, crossAxisSpacing: 8, childAspectRatio: 1.1,
                children: types.map((t) {
                  final sel = _type == t['t'];
                  return GestureDetector(
                    onTap: () => setState(() => _type = t['t'] as PackageType),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 150),
                      decoration: BoxDecoration(
                        color: sel ? AppColors.cyan.withOpacity(0.08) : AppColors.surface2,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: sel ? AppColors.cyan.withOpacity(0.4) : AppColors.border, width: sel ? 1.5 : 1),
                      ),
                      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                        Text(t['e'] as String, style: const TextStyle(fontSize: 24)),
                        const SizedBox(height: 4),
                        Text(t['l'] as String, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w500, color: sel ? AppColors.cyan : AppColors.textSecondary)),
                      ]),
                    ),
                  );
                }).toList(),
              ),
              const SizedBox(height: 20),
              const Text('TAILLE', style: TextStyle(fontFamily: 'SpaceMono', fontSize: 10, color: AppColors.textSecondary)),
              const SizedBox(height: 10),
              Row(
                children: sizes.map((s) {
                  final sel = _size == s['s'];
                  return Expanded(
                    child: GestureDetector(
                      onTap: () => setState(() => _size = s['s'] as PackageSize),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 150),
                        margin: const EdgeInsets.only(right: 6),
                        padding: const EdgeInsets.symmetric(vertical: 10),
                        decoration: BoxDecoration(
                          color: sel ? AppColors.cyan.withOpacity(0.06) : AppColors.surface2,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: sel ? AppColors.cyan : AppColors.border, width: sel ? 1.5 : 1),
                        ),
                        child: Column(children: [
                          Text(s['e'] as String, style: const TextStyle(fontSize: 18)),
                          const SizedBox(height: 4),
                          Text(s['l'] as String, style: TextStyle(fontSize: 10, color: sel ? AppColors.cyan : AppColors.textSecondary)),
                          Text(s['k'] as String, style: const TextStyle(fontFamily: 'SpaceMono', fontSize: 8, color: AppColors.textTertiary)),
                        ]),
                      ),
                    ),
                  );
                }).toList(),
              ),
              if (_size == PackageSize.xxl)
                const Padding(
                  padding: EdgeInsets.only(top: 10),
                  child: AlertBanner(message: 'Pour les objets XXL, un vehicule utilitaire sera requis.', type: AlertType.warning),
                ),
              const SizedBox(height: 20),
              const Text('OPTIONS', style: TextStyle(fontFamily: 'SpaceMono', fontSize: 10, color: AppColors.textSecondary)),
              const SizedBox(height: 10),
              LDCard(
                child: Column(children: [
                  _opt('Livraison securisee', 'Assurance colis +2€', _isInsured, (v) => setState(() => _isInsured = v)),
                  const Divider(color: AppColors.border),
                  _opt('Colis fragile', 'Manipulation delicate requise', _isFragile, (v) => setState(() => _isFragile = v)),
                ]),
              ),
              LDButton(
                label: 'Continuer -> Informations',
                color: AppColors.yellow,
                onTap: () {
                  context.read<DeliveryProvider>().setPackage(PackageModel(type: _type, size: _size, isFragile: _isFragile, isInsured: _isInsured));
                  context.go('/client/create/step3');
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _opt(String title, String sub, bool val, ValueChanged<bool> cb) {
    return Row(children: [
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500)),
        Text(sub, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
      ])),
      Switch.adaptive(value: val, onChanged: cb, activeColor: AppColors.cyan),
    ]);
  }
}
