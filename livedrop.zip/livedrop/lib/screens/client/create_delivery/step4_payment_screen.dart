
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../../core/theme/app_theme.dart';
import '../../../providers/providers.dart';
import '../../../widgets/common/widgets.dart';

class Step4PaymentScreen extends StatefulWidget {
  const Step4PaymentScreen({super.key});
  @override
  State<Step4PaymentScreen> createState() => _Step4State();
}

class _Step4State extends State<Step4PaymentScreen> {
  int _sel = 0;
  bool _processing = false;

  Future<void> _pay() async {
    setState(() => _processing = true);
    final delivery = context.read<DeliveryProvider>();
    final auth = context.read<AuthProvider>();
    await delivery.createDelivery(auth.user!.id);
    if (!mounted) return;
    setState(() => _processing = false);
    context.go('/client/finding');
  }

  @override
  Widget build(BuildContext context) {
    final delivery = context.watch<DeliveryProvider>();
    final pricing = delivery.currentPricing;
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(icon: const Icon(Icons.arrow_back, size: 20), onPressed: () => context.go('/client/create/step3')),
        title: const Text('Recap & paiement', style: TextStyle(fontFamily: 'Syne', fontSize: 17, fontWeight: FontWeight.w700)),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              DeliveryProgressSteps(currentStep: 3),
              const SizedBox(height: 20),
              const AlertBanner(message: 'Paiement chiffre SSL — Powered by Stripe Connect', type: AlertType.info),
              if (delivery.package != null)
                LDCard(
                  borderColor: AppColors.cyan.withOpacity(0.2),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      Column(children: [
                        Container(width: 8, height: 8, decoration: const BoxDecoration(color: AppColors.yellow, shape: BoxShape.circle)),
                        Container(width: 1, height: 26, color: AppColors.border),
                        Container(width: 8, height: 8, decoration: BoxDecoration(color: AppColors.cyan, borderRadius: BorderRadius.circular(2))),
                      ]),
                      const SizedBox(width: 12),
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(delivery.pickupLocation?.address ?? '', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w500)),
                        const SizedBox(height: 14),
                        Text(delivery.dropoffLocation?.address ?? '', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w500)),
                      ])),
                    ]),
                    const SizedBox(height: 10),
                    Wrap(spacing: 6, children: [
                      LDTag.yellow('${delivery.package!.typeEmoji} ${delivery.package!.typeLabel}'),
                      LDTag.cyan('${delivery.estimatedDistance.toStringAsFixed(1)} km'),
                      if (delivery.package!.isInsured) LDTag.purple('Assure'),
                    ]),
                  ]),
                ),
              if (pricing != null)
                LDCard(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('DETAIL DU TARIF', style: TextStyle(fontFamily: 'Syne', fontSize: 12, fontWeight: FontWeight.w600)),
                    const SizedBox(height: 10),
                    _pRow('Prise en charge', pricing.baseFare),
                    _pRow('Distance', pricing.distanceFare),
                    if (pricing.typeSurcharge > 0) _pRow('Type / Taille', pricing.typeSurcharge),
                    if (pricing.insuranceFee > 0) _pRow('Assurance', pricing.insuranceFee),
                    const Divider(color: AppColors.border),
                    Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                      const Text('Total', style: TextStyle(fontWeight: FontWeight.w500)),
                      Text('${pricing.total.toStringAsFixed(2)} EUR',
                          style: const TextStyle(fontFamily: 'Syne', fontSize: 22, fontWeight: FontWeight.w800, color: AppColors.yellow)),
                    ]),
                  ]),
                ),
              const Text('MOYEN DE PAIEMENT', style: TextStyle(fontFamily: 'SpaceMono', fontSize: 10, color: AppColors.textSecondary)),
              const SizedBox(height: 10),
              _payOpt(0, '💳', 'Carte 4242', 'Visa · Defaut'),
              _payOpt(1, '🍎', 'Apple Pay', ''),
              _payOpt(2, '🔵', 'Google Pay', ''),
              LDCard(
                color: AppColors.yellow.withOpacity(0.04),
                borderColor: AppColors.yellow.withOpacity(0.2),
                child: Row(children: [
                  const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('Solde LiveDrop', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w500)),
                    Text('Credit disponible', style: TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                  ])),
                  const Text('5,00 EUR', style: TextStyle(fontFamily: 'Syne', fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.yellow)),
                ]),
              ),
              const SizedBox(height: 10),
              LDButton(
                label: pricing != null ? 'Payer ${pricing.total.toStringAsFixed(2)} EUR ->' : 'Payer ->',
                color: AppColors.yellow,
                isLoading: _processing,
                onTap: _pay,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _pRow(String label, double val) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 4),
    child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Text(label, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
      Text('${val.toStringAsFixed(2)} EUR', style: const TextStyle(fontSize: 12)),
    ]),
  );

  Widget _payOpt(int idx, String ico, String title, String sub) {
    final sel = _sel == idx;
    return GestureDetector(
      onTap: () => setState(() => _sel = idx),
      child: LDCard(
        borderColor: sel ? AppColors.cyan.withOpacity(0.4) : null,
        child: Row(children: [
          Text(ico, style: const TextStyle(fontSize: 20)),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500)),
            if (sub.isNotEmpty) Text(sub, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
          ])),
          if (sel) LDTag.cyan('Selectionne'),
        ]),
      ),
    );
  }
}
