import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../providers/providers.dart';
import '../../widgets/common/widgets.dart';

class ClientHomeScreen extends StatelessWidget {
  const ClientHomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final delivery = context.watch<DeliveryProvider>();
    final user = auth.user!;

    return Scaffold(
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Header
                    Row(
                      children: [
                        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          const Text('Bonjour 👋',
                              style: TextStyle(
                                  fontSize: 13, color: AppColors.textSecondary)),
                          Text(user.displayName,
                              style: const TextStyle(
                                  fontFamily: 'Syne',
                                  fontSize: 22,
                                  fontWeight: FontWeight.w700)),
                        ]),
                        const Spacer(),
                        GestureDetector(
                          onTap: () => context.go('/client/notifications'),
                          child: Stack(
                            children: [
                              Container(
                                width: 40, height: 40,
                                decoration: BoxDecoration(
                                    color: AppColors.surface2,
                                    shape: BoxShape.circle,
                                    border: Border.all(color: AppColors.border)),
                                child: const Icon(Icons.notifications_outlined,
                                    size: 20, color: AppColors.textPrimary),
                              ),
                              Positioned(
                                top: 0, right: 0,
                                child: Container(
                                  width: 16, height: 16,
                                  decoration: const BoxDecoration(
                                      color: AppColors.red,
                                      shape: BoxShape.circle),
                                  child: const Center(
                                      child: Text('3',
                                          style: TextStyle(
                                              fontSize: 9,
                                              color: Colors.white,
                                              fontWeight: FontWeight.w700))),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 10),
                        CircleAvatar(
                          radius: 20,
                          backgroundColor: AppColors.surface3,
                          child: Text(user.firstName[0],
                              style: const TextStyle(
                                  fontFamily: 'Syne',
                                  fontWeight: FontWeight.w700,
                                  color: AppColors.textPrimary)),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),

                    // Active delivery banner
                    if (delivery.activeDelivery?.isActive == true)
                      GestureDetector(
                        onTap: () => context.go('/client/tracking'),
                        child: Container(
                          margin: const EdgeInsets.only(bottom: 14),
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: AppColors.surface2,
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(
                                color: AppColors.cyan.withOpacity(0.3)),
                            boxShadow: [
                              BoxShadow(
                                  color: AppColors.cyan.withOpacity(0.06),
                                  blurRadius: 20)
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  const LiveStatusBadge(label: 'EN COURS'),
                                  const Spacer(),
                                  const Text('Voir →',
                                      style: TextStyle(
                                          fontSize: 12,
                                          color: AppColors.cyan)),
                                ],
                              ),
                              const SizedBox(height: 10),
                              Row(
                                children: [
                                  Container(
                                    width: 10, height: 10,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: AppColors.cyan,
                                      boxShadow: [
                                        BoxShadow(
                                            color: AppColors.cyan
                                                .withOpacity(0.6),
                                            blurRadius: 8)
                                      ],
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  const Text('Karim B. — ETA ',
                                      style: TextStyle(
                                          fontSize: 13,
                                          fontWeight: FontWeight.w500)),
                                  const Text('8 min',
                                      style: TextStyle(
                                          fontFamily: 'SpaceMono',
                                          fontSize: 13,
                                          fontWeight: FontWeight.w700,
                                          color: AppColors.cyan)),
                                ],
                              ),
                              const SizedBox(height: 10),
                              Container(
                                height: 4,
                                decoration: BoxDecoration(
                                    color: AppColors.surface3,
                                    borderRadius: BorderRadius.circular(2)),
                                child: FractionallySizedBox(
                                  alignment: Alignment.centerLeft,
                                  widthFactor: 0.65,
                                  child: Container(
                                    decoration: BoxDecoration(
                                      gradient: const LinearGradient(
                                          colors: [
                                            AppColors.cyan,
                                            AppColors.yellow
                                          ]),
                                      borderRadius: BorderRadius.circular(2),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),

                    LDButton(
                      label: '+ Nouvelle livraison',
                      color: AppColors.yellow,
                      onTap: () => context.go('/client/create/step1'),
                    ),
                    const SizedBox(height: 20),

                    GridView.count(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      crossAxisCount: 2,
                      mainAxisSpacing: 10,
                      crossAxisSpacing: 10,
                      childAspectRatio: 2.0,
                      children: [
                        StatBox(
                            value: '${user.totalDeliveries}',
                            label: 'LIVRAISONS',
                            valueColor: AppColors.yellow,
                            delta: '↑ +3 ce mois'),
                        StatBox(
                            value: '${user.rating} ★',
                            label: 'MA NOTE',
                            valueColor: AppColors.cyan),
                      ],
                    ),
                    const SizedBox(height: 20),
                    SectionHeader(
                        title: 'Livraisons récentes',
                        action: 'Voir tout',
                        onAction: () => context.go('/client/history')),
                  ],
                ),
              ),
            ),
            SliverList(
              delegate: SliverChildBuilderDelegate(
                (ctx, i) {
                  if (i >= delivery.history.length) {
                    return const SizedBox(height: 80);
                  }
                  final d = delivery.history[i];
                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: LDCard(
                      child: Row(
                        children: [
                          Text(d.package.typeEmoji,
                              style: const TextStyle(fontSize: 22)),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  '${d.pickupLocation.city ?? ""} → ${d.dropoffLocation.city ?? ""}',
                                  style: const TextStyle(
                                      fontSize: 13,
                                      fontWeight: FontWeight.w500),
                                ),
                                Text(
                                  '${d.package.typeLabel} · ${d.pricing.total.toStringAsFixed(2)} €',
                                  style: const TextStyle(
                                      fontFamily: 'SpaceMono',
                                      fontSize: 10,
                                      color: AppColors.textSecondary),
                                ),
                              ],
                            ),
                          ),
                          LDTag.green('✓ Livré'),
                        ],
                      ),
                    ),
                  );
                },
                childCount: delivery.history.length + 1,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
