
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../models/models.dart';
import '../../providers/providers.dart';
import '../../widgets/common/widgets.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});
  @override
  State<HistoryScreen> createState() => _HistoryState();
}

class _HistoryState extends State<HistoryScreen> {
  PackageType? _filter;

  @override
  Widget build(BuildContext context) {
    final delivery = context.watch<DeliveryProvider>();
    final filtered = _filter == null ? delivery.history : delivery.history.where((d) => d.package.type == _filter).toList();
    final total = delivery.history.fold(0.0, (s, d) => s + d.pricing.total);
    return Scaffold(
      appBar: AppBar(title: const Text('Historique', style: TextStyle(fontFamily: 'Syne', fontSize: 20, fontWeight: FontWeight.w700))),
      body: SafeArea(child: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 8),
          child: Row(children: [
            Expanded(child: StatBox(value: '${delivery.history.length}', label: 'LIVRAISONS', valueColor: AppColors.yellow)),
            const SizedBox(width: 10),
            Expanded(child: StatBox(value: '${total.toStringAsFixed(0)} EUR', label: 'DEPENSES', valueColor: AppColors.cyan)),
          ]),
        ),
        SizedBox(
          height: 40,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 20),
            children: [
              _chip('Tous', null),
              _chip('Colis', PackageType.parcel),
              _chip('Repas', PackageType.food),
              _chip('Meuble', PackageType.furniture),
              _chip('Document', PackageType.document),
            ],
          ),
        ),
        const SizedBox(height: 8),
        Expanded(
          child: filtered.isEmpty
              ? const Center(child: Text('Aucune livraison', style: TextStyle(color: AppColors.textSecondary)))
              : ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  itemCount: filtered.length,
                  itemBuilder: (_, i) {
                    final d = filtered[i];
                    return LDCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                        Text('${d.pickupLocation.city} -> ${d.dropoffLocation.city}', style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500)),
                        Text('${d.pricing.total.toStringAsFixed(2)} EUR', style: const TextStyle(fontFamily: 'Syne', fontWeight: FontWeight.w700, color: AppColors.yellow)),
                      ]),
                      const SizedBox(height: 5),
                      Text('${d.package.typeEmoji} ${d.package.typeLabel} · ${d.distanceKm?.toStringAsFixed(1) ?? "?"} km · ${d.durationMinutes ?? "?"} min',
                          style: const TextStyle(fontFamily: 'SpaceMono', fontSize: 10, color: AppColors.textSecondary)),
                      const SizedBox(height: 8),
                      Row(children: [LDTag.green('Livre')]),
                    ]));
                  },
                ),
        ),
      ])),
    );
  }

  Widget _chip(String label, PackageType? type) {
    final sel = _filter == type;
    return GestureDetector(
      onTap: () => setState(() => _filter = type),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        margin: const EdgeInsets.only(right: 8),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        decoration: BoxDecoration(
          color: sel ? AppColors.cyan : AppColors.surface2,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: sel ? AppColors.cyan : AppColors.border),
        ),
        child: Text(label, style: TextStyle(fontFamily: 'SpaceMono', fontSize: 10, fontWeight: FontWeight.w600, color: sel ? const Color(0xFF060C16) : AppColors.textSecondary)),
      ),
    );
  }
}
