import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../providers/providers.dart';

class ClientShell extends StatelessWidget {
  final Widget child;
  const ClientShell({super.key, required this.child});

  int _idx(BuildContext context) {
    final loc = GoRouterState.of(context).matchedLocation;
    if (loc.startsWith('/client/history')) return 1;
    if (loc.startsWith('/client/notifications')) return 2;
    if (loc.startsWith('/client/profile')) return 3;
    return 0;
  }

  @override
  Widget build(BuildContext context) {
    final notifs = context.watch<NotificationProvider>();
    final delivery = context.watch<DeliveryProvider>();
    final idx = _idx(context);
    return Scaffold(
      body: child,
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          border: Border(top: BorderSide(color: AppColors.border)),
          color: AppColors.surface1,
        ),
        child: SafeArea(
          child: Row(
            children: [
              _navItem(context, Icons.home_outlined, 'Accueil', idx == 0,
                  route: '/client',
                  badge: delivery.activeDelivery?.isActive == true ? '1' : null),
              _navItem(context, Icons.receipt_long_outlined, 'Historique',
                  idx == 1, route: '/client/history'),
              // Centre FAB
              Expanded(
                child: GestureDetector(
                  onTap: () => context.go('/client/create/step1'),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 46,
                        height: 46,
                        decoration: BoxDecoration(
                          color: AppColors.yellow,
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(
                                color: AppColors.yellow.withOpacity(0.35),
                                blurRadius: 12)
                          ],
                        ),
                        child: const Icon(Icons.add,
                            color: Color(0xFF060C16), size: 24),
                      ),
                      const SizedBox(height: 2),
                      const Text('Livrer',
                          style: TextStyle(
                              fontFamily: 'SpaceMono',
                              fontSize: 9,
                              color: AppColors.textTertiary)),
                    ],
                  ),
                ),
              ),
              _navItem(context, Icons.notifications_outlined, 'Alertes',
                  idx == 2,
                  route: '/client/notifications',
                  badge: notifs.unreadCount > 0
                      ? '${notifs.unreadCount}'
                      : null),
              _navItem(context, Icons.person_outline, 'Profil', idx == 3,
                  route: '/client/profile'),
            ],
          ),
        ),
      ),
    );
  }

  Widget _navItem(
    BuildContext context,
    IconData icon,
    String label,
    bool active, {
    required String route,
    String? badge,
  }) {
    return Expanded(
      child: GestureDetector(
        onTap: () => context.go(route),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Stack(
                clipBehavior: Clip.none,
                children: [
                  Icon(icon,
                      size: 22,
                      color: active
                          ? AppColors.cyan
                          : AppColors.textTertiary),
                  if (badge != null)
                    Positioned(
                      top: -4,
                      right: -6,
                      child: Container(
                        width: 16,
                        height: 16,
                        decoration: const BoxDecoration(
                            color: AppColors.red, shape: BoxShape.circle),
                        child: Center(
                            child: Text(badge,
                                style: const TextStyle(
                                    fontSize: 9,
                                    color: Colors.white,
                                    fontWeight: FontWeight.w700))),
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 2),
              Text(label,
                  style: TextStyle(
                      fontFamily: 'SpaceMono',
                      fontSize: 9,
                      color: active
                          ? AppColors.cyan
                          : AppColors.textTertiary)),
            ],
          ),
        ),
      ),
    );
  }
}
