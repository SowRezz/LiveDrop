
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../providers/providers.dart';
import '../../widgets/common/widgets.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});
  @override
  State<ChatScreen> createState() => _ChatState();
}

class _ChatState extends State<ChatScreen> {
  final _ctrl = TextEditingController();
  final _scroll = ScrollController();

  @override
  void initState() {
    super.initState();
    context.read<ChatProvider>().loadMockMessages('usr_001', 'drv_001');
  }
  @override
  void dispose() { _ctrl.dispose(); _scroll.dispose(); super.dispose(); }

  void _send() async {
    final text = _ctrl.text.trim();
    if (text.isEmpty) return;
    _ctrl.clear();
    await context.read<ChatProvider>().sendMessage(senderId: 'usr_001', content: text);
    await Future.delayed(const Duration(milliseconds: 100));
    if (_scroll.hasClients) _scroll.animateTo(_scroll.position.maxScrollExtent, duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
  }

  @override
  Widget build(BuildContext context) {
    final chat = context.watch<ChatProvider>();
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(icon: const Icon(Icons.arrow_back, size: 20), onPressed: () => context.go('/client/tracking')),
        title: Row(children: [
          CircleAvatar(radius: 16, backgroundColor: AppColors.surface3, child: const Text('K', style: TextStyle(fontFamily: 'Syne', fontWeight: FontWeight.w700, fontSize: 13, color: AppColors.textPrimary))),
          const SizedBox(width: 10),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
            Text('Karim Benali', style: TextStyle(fontFamily: 'Syne', fontSize: 14, fontWeight: FontWeight.w600)),
            LiveStatusBadge(label: 'EN ROUTE'),
          ]),
        ]),
        actions: [IconButton(icon: const Icon(Icons.phone_outlined, size: 20), onPressed: () {})],
      ),
      body: SafeArea(
        child: Column(children: [
          Expanded(
            child: ListView.builder(
              controller: _scroll,
              padding: const EdgeInsets.all(16),
              itemCount: chat.messages.length + 1,
              itemBuilder: (_, i) {
                if (i == chat.messages.length) {
                  return Wrap(spacing: 8, runSpacing: 8, children: [
                    _qr('👍 Ok merci'), _qr('📍 Je descends'), _qr('⏳ 5 min'),
                  ]);
                }
                final msg = chat.messages[i];
                final isMe = msg.senderId == 'usr_001';
                return Align(
                  alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 8),
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
                    decoration: BoxDecoration(
                      color: isMe ? AppColors.cyan.withOpacity(0.15) : AppColors.surface2,
                      borderRadius: BorderRadius.only(
                        topLeft: const Radius.circular(12), topRight: const Radius.circular(12),
                        bottomLeft: Radius.circular(isMe ? 12 : 2),
                        bottomRight: Radius.circular(isMe ? 2 : 12),
                      ),
                      border: Border.all(color: isMe ? AppColors.cyan.withOpacity(0.2) : AppColors.border),
                    ),
                    child: Text(msg.content, style: const TextStyle(fontSize: 13, height: 1.4)),
                  ),
                );
              },
            ),
          ),
          Container(
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 14),
            decoration: const BoxDecoration(border: Border(top: BorderSide(color: AppColors.border))),
            child: Row(children: [
              Expanded(
                child: Container(
                  decoration: BoxDecoration(color: AppColors.surface2, borderRadius: BorderRadius.circular(24), border: Border.all(color: AppColors.border)),
                  child: TextField(
                    controller: _ctrl,
                    style: const TextStyle(fontSize: 13, color: AppColors.textPrimary),
                    decoration: const InputDecoration(hintText: 'Message...', border: InputBorder.none, contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 10)),
                    onSubmitted: (_) => _send(),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              GestureDetector(
                onTap: _send,
                child: Container(
                  width: 40, height: 40,
                  decoration: BoxDecoration(color: AppColors.cyan, shape: BoxShape.circle, boxShadow: [BoxShadow(color: AppColors.cyan.withOpacity(0.3), blurRadius: 8)]),
                  child: const Icon(Icons.send_rounded, size: 18, color: Color(0xFF060C16)),
                ),
              ),
            ]),
          ),
        ]),
      ),
    );
  }

  Widget _qr(String t) => GestureDetector(
    onTap: () => context.read<ChatProvider>().sendMessage(senderId: 'usr_001', content: t),
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(color: AppColors.surface3, borderRadius: BorderRadius.circular(16), border: Border.all(color: AppColors.border)),
      child: Text(t, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
    ),
  );
}
