
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../models/models.dart';
import '../../providers/providers.dart';
import '../../widgets/common/widgets.dart';

class TrackingScreen extends StatelessWidget {
  const TrackingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final delivery = context.watch<DeliveryProvider>();
    final d = delivery.activeDelivery ?? DeliveryModel.mock;

    return Scaffold(
      body: SafeArea(
        child: Column(children: [
          // MAP
          Container(
            height: 240,
            decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF0A1420), Color(0xFF0D1828)])),
            child: Stack(children: [
              CustomPaint(size: const Size(double.infinity, 240), painter: _MapPainter()),
              Positioned(top: 12, left: 12,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(color: const Color(0xFF0D1220).withOpacity(0.92), borderRadius: BorderRadius.circular(10), border: Border.all(color: AppColors.cyan.withOpacity(0.3))),
                  child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('ETA', style: TextStyle(fontFamily: 'SpaceMono', fontSize: 10, color: AppColors.cyan)),
                    Text('8 min', style: TextStyle(fontFamily: 'Syne', fontSize: 22, fontWeight: FontWeight.w800)),
                  ]),
                ),
              ),
              Positioned(top: 12, right: 12,
                child: Column(children: [
                  GestureDetector(
                    onTap: () => context.go('/client/chat'),
                    child: Container(width: 36, height: 36, decoration: BoxDecoration(color: const Color(0xFF0D1220).withOpacity(0.9), shape: BoxShape.circle, border: Border.all(color: AppColors.border)),
                      child: const Icon(Icons.chat_bubble_outline, size: 16, color: AppColors.textPrimary)),
                  ),
                  const SizedBox(height: 8),
                  Container(width: 36, height: 36, decoration: BoxDecoration(color: const Color(0xFF0D1220).withOpacity(0.9), shape: BoxShape.circle, border: Border.all(color: AppColors.border)),
                    child: const Icon(Icons.phone_outlined, size: 16, color: AppColors.textPrimary)),
                ]),
              ),
            ]),
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                DeliveryProgressSteps(currentStep: 2),
                const SizedBox(height: 14),
                const AlertBanner(message: 'Karim est en route · Il sera la dans 8 min', type: AlertType.info),
                LDCard(child: Column(children: [
                  Row(children: [
                    CircleAvatar(radius: 26, backgroundColor: AppColors.surface3,
                      child: const Text('K', style: TextStyle(fontFamily: 'Syne', fontSize: 20, fontWeight: FontWeight.w700, color: AppColors.textPrimary))),
                    const SizedBox(width: 12),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      const Text('Karim Benali', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
                      const Text('4.9 · 142 livraisons · Honda CB500F', style: TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                      const SizedBox(height: 4),
                      Row(children: [LDTag.green('Verifie'), const SizedBox(width: 6), LDTag.cyan('Top livreur')]),
                    ])),
                    Column(children: [
                      GestureDetector(
                        onTap: () => context.go('/client/chat'),
                        child: Container(width: 32, height: 32, decoration: BoxDecoration(color: AppColors.surface3, shape: BoxShape.circle, border: Border.all(color: AppColors.border)),
                          child: const Icon(Icons.chat_bubble_outline, size: 15, color: AppColors.textPrimary)),
                      ),
                      const SizedBox(height: 6),
                      Container(width: 32, height: 32, decoration: BoxDecoration(color: AppColors.surface3, shape: BoxShape.circle, border: Border.all(color: AppColors.border)),
                        child: const Icon(Icons.phone_outlined, size: 15, color: AppColors.textPrimary)),
                    ]),
                  ]),
                  const SizedBox(height: 10),
                  Container(padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: AppColors.surface3, borderRadius: BorderRadius.circular(8)),
                    child: const Row(children: [
                      Text('🏍️', style: TextStyle(fontSize: 16)),
                      SizedBox(width: 8),
                      Text('Honda CB500F', style: TextStyle(fontSize: 12)),
                      SizedBox(width: 12),
                      Text('AB-123-CD', style: TextStyle(fontFamily: 'SpaceMono', fontSize: 11, color: AppColors.textSecondary)),
                    ]),
                  ),
                ])),
                SectionHeader(title: 'Historique en direct'),
                _tl('Mission acceptee', '09:47', AppColors.green, true),
                _tl('En route vers le depart', '09:49', AppColors.cyan, true),
                _tl('Colis recupere...', '', AppColors.textTertiary, false),
                const SizedBox(height: 16),
                LDButton(
                  label: 'Simuler la livraison ->',
                  outline: true,
                  onTap: () {
                    delivery.updateStatus(DeliveryStatus.delivered);
                    context.go('/client/delivered');
                  },
                ),
              ]),
            ),
          ),
        ]),
      ),
    );
  }

  Widget _tl(String title, String time, Color c, bool more) {
    return Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Column(children: [
        Container(width: 10, height: 10, decoration: BoxDecoration(shape: BoxShape.circle, color: c)),
        if (more) Container(width: 1, height: 28, color: AppColors.border),
      ]),
      const SizedBox(width: 12),
      Expanded(child: Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w500, color: more ? AppColors.textPrimary : AppColors.textSecondary)),
          if (time.isNotEmpty) Text(time, style: const TextStyle(fontFamily: 'SpaceMono', fontSize: 10, color: AppColors.textSecondary)),
        ]),
      )),
    ]);
  }
}

class _MapPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size s) {
    final g = Paint()..color = AppColors.cyan.withOpacity(0.04)..strokeWidth = 1;
    for (double x = 0; x < s.width; x += 28) canvas.drawLine(Offset(x, 0), Offset(x, s.height), g);
    for (double y = 0; y < s.height; y += 28) canvas.drawLine(Offset(0, y), Offset(s.width, y), g);
    final r = Paint()..color = Colors.white.withOpacity(0.07)..strokeWidth = 5;
    canvas.drawLine(Offset(0, s.height * 0.48), Offset(s.width, s.height * 0.48), r);
    canvas.drawLine(Offset(s.width * 0.55, 0), Offset(s.width * 0.55, s.height), r);
    final rt = Paint()..color = AppColors.cyan.withOpacity(0.5)..strokeWidth = 2.5..style = PaintingStyle.stroke;
    final p = Path()..moveTo(s.width * 0.22, s.height * 0.48)..cubicTo(s.width * 0.4, s.height * 0.3, s.width * 0.55, s.height * 0.4, s.width * 0.8, s.height * 0.28);
    canvas.drawPath(p, rt);
    final dp = Paint()..color = AppColors.cyan;
    canvas.drawCircle(Offset(s.width * 0.5, s.height * 0.42), 7, dp);
    canvas.drawCircle(Offset(s.width * 0.5, s.height * 0.42), 13, dp..color = AppColors.cyan.withOpacity(0.2));
    _pin(canvas, s.width * 0.22, s.height * 0.48, AppColors.yellow, 'A');
    _pin(canvas, s.width * 0.8, s.height * 0.28, AppColors.cyan, 'B');
  }
  void _pin(Canvas c, double x, double y, Color col, String lbl) {
    c.drawCircle(Offset(x, y - 14), 10, Paint()..color = col);
    final tp = TextPainter(text: TextSpan(text: lbl, style: TextStyle(color: const Color(0xFF060C16), fontSize: 9, fontWeight: FontWeight.w700)), textDirection: TextDirection.ltr)..layout();
    tp.paint(c, Offset(x - tp.width / 2, y - 14 - tp.height / 2));
  }
  @override
  bool shouldRepaint(_) => false;
}
