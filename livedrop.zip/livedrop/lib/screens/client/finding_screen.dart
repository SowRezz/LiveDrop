
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../providers/providers.dart';
import '../../widgets/common/widgets.dart';

class FindingScreen extends StatefulWidget {
  const FindingScreen({super.key});
  @override
  State<FindingScreen> createState() => _FindingState();
}

class _FindingState extends State<FindingScreen> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Timer _t;
  int _si = 0;
  final _s = ['Connexion au reseau...', 'Localisation des livreurs...', 'Envoi de la mission...', 'Livreur trouve!'];

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1800))..repeat();
    _t = Timer.periodic(const Duration(milliseconds: 900), (t) {
      if (_si < _s.length - 1) {
        setState(() => _si++);
      } else {
        t.cancel();
        Future.delayed(const Duration(milliseconds: 600), () {
          if (mounted) context.go('/client/tracking');
        });
      }
    });
  }

  @override
  void dispose() { _ctrl.dispose(); _t.cancel(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(
                width: 120, height: 120,
                child: Stack(alignment: Alignment.center, children: [
                  ...List.generate(3, (i) => AnimatedBuilder(
                    animation: _ctrl,
                    builder: (_, __) {
                      final v = ((_ctrl.value - i * 0.25) % 1.0).clamp(0.0, 1.0);
                      return Container(
                        width: 120, height: 120,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(color: AppColors.cyan.withOpacity((1 - v) * 0.4), width: 2),
                        ),
                        transform: Matrix4.identity()..scale(0.5 + v * 0.5),
                      );
                    },
                  )),
                  const Text('🛵', style: TextStyle(fontSize: 36)),
                ]),
              ),
              const SizedBox(height: 32),
              const Text('Recherche du livreur...', style: TextStyle(fontFamily: 'Syne', fontSize: 20, fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              AnimatedSwitcher(
                duration: const Duration(milliseconds: 300),
                child: Text(_s[_si], key: ValueKey(_si), style: const TextStyle(fontFamily: 'SpaceMono', fontSize: 12, color: AppColors.textSecondary)),
              ),
              const SizedBox(height: 32),
              LDCard(child: Column(children: [
                _row('Livreurs en ligne', '4', AppColors.green),
                const Divider(color: AppColors.border),
                _row('Distance plus proche', '1.2 km', AppColors.cyan),
                const Divider(color: AppColors.border),
                _row('ETA estime', '8-12 min', AppColors.yellow),
              ])),
              const SizedBox(height: 20),
              LDButton(label: 'Annuler', outline: true, onTap: () {
                context.read<DeliveryProvider>().resetCreateFlow();
                context.go('/client');
              }),
            ],
          ),
        ),
      ),
    );
  }

  Widget _row(String l, String v, Color c) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 8),
    child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Text(l, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
      Text(v, style: TextStyle(fontFamily: 'SpaceMono', fontSize: 12, fontWeight: FontWeight.w700, color: c)),
    ]),
  );
}
