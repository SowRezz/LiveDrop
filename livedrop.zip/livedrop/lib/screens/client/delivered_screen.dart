
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../providers/providers.dart';
import '../../widgets/common/widgets.dart';

class DeliveredScreen extends StatefulWidget {
  const DeliveredScreen({super.key});
  @override
  State<DeliveredScreen> createState() => _DeliveredState();
}

class _DeliveredState extends State<DeliveredScreen> with SingleTickerProviderStateMixin {
  double _rating = 4;
  final _commentCtrl = TextEditingController();
  final Set<String> _tags = {};
  late AnimationController _pop;
  late Animation<double> _popAnim;

  @override
  void initState() {
    super.initState();
    _pop = AnimationController(vsync: this, duration: const Duration(milliseconds: 500));
    _popAnim = CurvedAnimation(parent: _pop, curve: Curves.elasticOut);
    _pop.forward();
  }
  @override
  void dispose() { _pop.dispose(); _commentCtrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final delivery = context.watch<DeliveryProvider>();
    final d = delivery.activeDelivery;
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Column(children: [
            const SizedBox(height: 32),
            ScaleTransition(
              scale: _popAnim,
              child: Container(
                width: 80, height: 80,
                decoration: BoxDecoration(shape: BoxShape.circle, color: AppColors.green.withOpacity(0.08), border: Border.all(color: AppColors.green, width: 2), boxShadow: [BoxShadow(color: AppColors.green.withOpacity(0.2), blurRadius: 20)]),
                child: const Center(child: Text('OK', style: TextStyle(fontFamily: 'Syne', fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.green))),
              ),
            ),
            const SizedBox(height: 20),
            const Text('Colis livre!', style: TextStyle(fontFamily: 'Syne', fontSize: 26, fontWeight: FontWeight.w800)),
            const SizedBox(height: 6),
            if (d != null) Text('Livre a ${d.dropoffLocation.address}', textAlign: TextAlign.center, style: const TextStyle(fontSize: 13, color: AppColors.textSecondary)),
            const SizedBox(height: 28),
            if (d != null) LDCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('RECU', style: TextStyle(fontFamily: 'SpaceMono', fontSize: 10, color: AppColors.textSecondary)),
              const SizedBox(height: 8),
              _r('Duree', '${d.durationMinutes ?? 17} min'),
              _r('Distance', '${d.distanceKm?.toStringAsFixed(1) ?? "3.2"} km'),
              _r('Montant', '${d.pricing.total.toStringAsFixed(2)} EUR', c: AppColors.yellow),
            ])),
            LDCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Notez votre livreur', style: TextStyle(fontFamily: 'Syne', fontSize: 14, fontWeight: FontWeight.w600)),
              const SizedBox(height: 4),
              const Text('Votre avis aide toute la communaute', style: TextStyle(fontSize: 12, color: AppColors.textSecondary)),
              const SizedBox(height: 16),
              Row(mainAxisAlignment: MainAxisAlignment.center, children: List.generate(5, (i) => GestureDetector(
                onTap: () => setState(() => _rating = (i + 1).toDouble()),
                child: Padding(padding: const EdgeInsets.symmetric(horizontal: 4), child: Text('*', style: TextStyle(fontSize: 34, color: i < _rating ? AppColors.yellow : AppColors.surface4))),
              ))),
              const SizedBox(height: 14),
              Wrap(spacing: 8, runSpacing: 8, children: ['Rapide', 'Sympa', 'Soin du colis', 'Ponctuel'].map((tag) {
                final sel = _tags.contains(tag);
                return GestureDetector(
                  onTap: () => setState(() => sel ? _tags.remove(tag) : _tags.add(tag)),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 150),
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: sel ? AppColors.cyan.withOpacity(0.12) : AppColors.surface3,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: sel ? AppColors.cyan.withOpacity(0.4) : AppColors.border),
                    ),
                    child: Text(tag, style: TextStyle(fontSize: 11, color: sel ? AppColors.cyan : AppColors.textSecondary)),
                  ),
                );
              }).toList()),
              const SizedBox(height: 12),
              TextField(controller: _commentCtrl, style: const TextStyle(fontSize: 13, color: AppColors.textPrimary), decoration: const InputDecoration(hintText: 'Commentaire optionnel...'), maxLines: 2),
            ])),
            LDButton(label: 'Envoyer et terminer', color: AppColors.yellow, onTap: () {
              delivery.rateDelivery(rating: _rating, comment: _commentCtrl.text);
              context.go('/client');
            }),
            const SizedBox(height: 8),
            LDButton(label: 'Plus tard', outline: true, onTap: () => context.go('/client')),
            const SizedBox(height: 20),
          ]),
        ),
      ),
    );
  }
  Widget _r(String l, String v, {Color? c}) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 4),
    child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Text(l, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
      Text(v, style: TextStyle(fontFamily: 'SpaceMono', fontSize: 12, color: c ?? AppColors.textPrimary)),
    ]),
  );
}
