import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import 'providers/providers.dart';
import 'screens/splash/splash_screen.dart';
import 'screens/auth/login_screen.dart';
import 'screens/auth/register_screen.dart';
import 'screens/auth/onboarding_screen.dart';
import 'screens/client/client_shell.dart';
import 'screens/client/home_screen.dart';
import 'screens/client/create_delivery/step1_address_screen.dart';
import 'screens/client/create_delivery/step2_package_screen.dart';
import 'screens/client/create_delivery/step3_details_screen.dart';
import 'screens/client/create_delivery/step4_payment_screen.dart';
import 'screens/client/finding_screen.dart';
import 'screens/client/tracking_screen.dart';
import 'screens/client/chat_screen.dart';
import 'screens/client/delivered_screen.dart';
import 'screens/client/history_screen.dart';
import 'screens/client/notifications_screen.dart';
import 'screens/client/profile_screen.dart';
import 'screens/driver/driver_shell.dart';
import 'screens/driver/home_screen.dart';
import 'screens/driver/mission_detail_screen.dart';
import 'screens/driver/navigation_screen.dart';
import 'screens/driver/qr_scan_screen.dart';
import 'screens/driver/earnings_screen.dart';
import 'screens/driver/driver_profile_screen.dart';
import 'screens/driver/paid_screen.dart';

final _rootKey = GlobalKey<NavigatorState>();
final _clientKey = GlobalKey<NavigatorState>();
final _driverKey = GlobalKey<NavigatorState>();

GoRouter createRouter(AuthProvider auth) => GoRouter(
      navigatorKey: _rootKey,
      initialLocation: '/splash',
      redirect: (context, state) {
        final loggedIn = auth.isAuthenticated;
        final goingToAuth = state.matchedLocation.startsWith('/auth') ||
            state.matchedLocation == '/splash' ||
            state.matchedLocation == '/onboarding';
        if (!loggedIn && !goingToAuth) return '/splash';
        if (loggedIn && goingToAuth) {
          return auth.isDriver ? '/driver' : '/client';
        }
        return null;
      },
      routes: [
        // ── Splash ──────────────────────────────
        GoRoute(
          path: '/splash',
          builder: (_, __) => const SplashScreen(),
        ),

        // ── Onboarding ──────────────────────────
        GoRoute(
          path: '/onboarding',
          builder: (_, __) => const OnboardingScreen(),
        ),

        // ── Auth ────────────────────────────────
        GoRoute(
          path: '/auth/login',
          builder: (_, __) => const LoginScreen(),
        ),
        GoRoute(
          path: '/auth/register',
          builder: (_, __) => const RegisterScreen(),
        ),

        // ── Client Shell ─────────────────────────
        ShellRoute(
          navigatorKey: _clientKey,
          builder: (_, __, child) => ClientShell(child: child),
          routes: [
            GoRoute(
              path: '/client',
              builder: (_, __) => const ClientHomeScreen(),
            ),
            GoRoute(
              path: '/client/history',
              builder: (_, __) => const HistoryScreen(),
            ),
            GoRoute(
              path: '/client/notifications',
              builder: (_, __) => const NotificationsScreen(),
            ),
            GoRoute(
              path: '/client/profile',
              builder: (_, __) => const ClientProfileScreen(),
            ),
          ],
        ),

        // ── Client full-screen flows ──────────────
        GoRoute(
          path: '/client/create/step1',
          builder: (_, __) => const Step1AddressScreen(),
        ),
        GoRoute(
          path: '/client/create/step2',
          builder: (_, __) => const Step2PackageScreen(),
        ),
        GoRoute(
          path: '/client/create/step3',
          builder: (_, __) => const Step3DetailsScreen(),
        ),
        GoRoute(
          path: '/client/create/step4',
          builder: (_, __) => const Step4PaymentScreen(),
        ),
        GoRoute(
          path: '/client/finding',
          builder: (_, __) => const FindingScreen(),
        ),
        GoRoute(
          path: '/client/tracking',
          builder: (_, __) => const TrackingScreen(),
        ),
        GoRoute(
          path: '/client/chat',
          builder: (_, __) => const ChatScreen(),
        ),
        GoRoute(
          path: '/client/delivered',
          builder: (_, __) => const DeliveredScreen(),
        ),

        // ── Driver Shell ─────────────────────────
        ShellRoute(
          navigatorKey: _driverKey,
          builder: (_, __, child) => DriverShell(child: child),
          routes: [
            GoRoute(
              path: '/driver',
              builder: (_, __) => const DriverHomeScreen(),
            ),
            GoRoute(
              path: '/driver/earnings',
              builder: (_, __) => const EarningsScreen(),
            ),
            GoRoute(
              path: '/driver/profile',
              builder: (_, __) => const DriverProfileScreen(),
            ),
          ],
        ),

        // ── Driver full-screen flows ──────────────
        GoRoute(
          path: '/driver/mission/:id',
          builder: (_, state) => MissionDetailScreen(
            deliveryId: state.pathParameters['id']!,
          ),
        ),
        GoRoute(
          path: '/driver/navigate/a',
          builder: (_, __) => const NavigationScreen(isPickup: true),
        ),
        GoRoute(
          path: '/driver/navigate/b',
          builder: (_, __) => const NavigationScreen(isPickup: false),
        ),
        GoRoute(
          path: '/driver/scan/pickup',
          builder: (_, __) => const QRScanScreen(isPickup: true),
        ),
        GoRoute(
          path: '/driver/paid',
          builder: (_, __) => const PaidScreen(),
        ),
        GoRoute(
          path: '/driver/scan/delivery',
          builder: (_, __) => const QRScanScreen(isPickup: false),
        ),
      ],
    );

// NOTE: Add this import at top of router.dart:
// import 'screens/driver/paid_screen.dart';
// And add this route inside the routes list:
// GoRoute(path: '/driver/paid', builder: (_, __) => const PaidScreen()),
