// ─────────────────────────────────────────
// SERVICES — LiveDrop
// ─────────────────────────────────────────
// Couche service : toutes les communications
// réseau, paiement, géolocalisation.
// En production, remplacer les mocks par
// les vraies implémentations API.

import 'dart:math';
import '../models/models.dart';

// ─── API SERVICE ─────────────────────────
class ApiService {
  static const String baseUrl = 'https://api.livedrop.fr/v1';
  // En production: utiliser Dio avec intercepteurs JWT

  static Future<Map<String, dynamic>> post(String endpoint, Map<String, dynamic> body) async {
    await Future.delayed(const Duration(milliseconds: 400));
    return {'success': true, 'data': body};
  }

  static Future<Map<String, dynamic>> get(String endpoint) async {
    await Future.delayed(const Duration(milliseconds: 300));
    return {'success': true};
  }
}

// ─── PAYMENT SERVICE ─────────────────────
class PaymentService {
  // En production: flutter_stripe avec clé publiable
  // const stripe = Stripe(publishableKey: 'pk_live_...');

  static Future<PaymentResult> createPaymentIntent({
    required double amount,
    required String currency,
    required String deliveryId,
  }) async {
    await Future.delayed(const Duration(milliseconds: 800));
    return PaymentResult(
      success: true,
      transactionId: 'pi_${DateTime.now().millisecondsSinceEpoch}',
      amount: amount,
    );
  }

  static Future<PaymentResult> processPayment({
    required String paymentIntentId,
    required String paymentMethodId,
  }) async {
    await Future.delayed(const Duration(seconds: 1));
    return PaymentResult(
      success: true,
      transactionId: paymentIntentId,
      amount: 0,
    );
  }

  static Future<void> releaseEscrow(String deliveryId) async {
    await Future.delayed(const Duration(milliseconds: 500));
    // Stripe Connect: libère les fonds vers le compte du livreur
  }

  static Future<void> refund(String paymentIntentId) async {
    await Future.delayed(const Duration(milliseconds: 600));
  }
}

class PaymentResult {
  final bool success;
  final String? transactionId;
  final String? error;
  final double amount;

  const PaymentResult({
    required this.success,
    this.transactionId,
    this.error,
    required this.amount,
  });
}

// ─── LOCATION SERVICE ────────────────────
class LocationService {
  static double calculateDistance(
    double lat1, double lon1,
    double lat2, double lon2,
  ) {
    const R = 6371.0; // Rayon de la Terre en km
    final dLat = _toRad(lat2 - lat1);
    final dLon = _toRad(lon2 - lon1);
    final a = sin(dLat / 2) * sin(dLat / 2) +
        cos(_toRad(lat1)) * cos(_toRad(lat2)) *
        sin(dLon / 2) * sin(dLon / 2);
    final c = 2 * atan2(sqrt(a), sqrt(1 - a));
    return R * c;
  }

  static double _toRad(double deg) => deg * pi / 180;

  static int estimateETA(double distanceKm, {double avgSpeedKmh = 25}) {
    return ((distanceKm / avgSpeedKmh) * 60).round() + 2;
  }

  static bool isWithinGeofence({
    required double driverLat,
    required double driverLng,
    required double routeLat,
    required double routeLng,
    double toleranceKm = 2.0,
  }) {
    final distance = calculateDistance(driverLat, driverLng, routeLat, routeLng);
    return distance <= toleranceKm;
  }
}

// ─── QR SERVICE ──────────────────────────
class QRService {
  static String generatePickupCode(String deliveryId) =>
      '$deliveryId-PICKUP-${DateTime.now().millisecondsSinceEpoch}';

  static String generateDropoffCode(String deliveryId) =>
      '$deliveryId-DROP-${DateTime.now().millisecondsSinceEpoch}';

  static bool validatePickupCode(String scanned, String expected) =>
      scanned.contains('PICKUP') && scanned.contains(expected.split('-')[0]);

  static bool validateDropoffCode(String scanned, String expected) =>
      scanned.contains('DROP') && scanned.contains(expected.split('-')[0]);
}

// ─── NOTIFICATION SERVICE ─────────────────
class NotificationService {
  // En production: firebase_messaging

  static Future<void> sendPushToDriver({
    required String driverId,
    required String title,
    required String body,
    Map<String, dynamic>? data,
  }) async {
    // POST à votre backend → Firebase Cloud Messaging
    await ApiService.post('/notifications/push', {
      'target': driverId,
      'title': title,
      'body': body,
      'data': data ?? {},
    });
  }

  static Future<void> sendPushToClient({
    required String clientId,
    required String title,
    required String body,
    Map<String, dynamic>? data,
  }) async {
    await ApiService.post('/notifications/push', {
      'target': clientId,
      'title': title,
      'body': body,
      'data': data ?? {},
    });
  }
}

// ─── SOCKET SERVICE ──────────────────────
class SocketService {
  // En production: socket_io_client
  // final socket = io('https://api.livedrop.fr', OptionBuilder()...);

  static void emitDriverLocation({
    required String driverId,
    required double lat,
    required double lng,
  }) {
    // socket.emit('driver:location', {'driverId': driverId, 'lat': lat, 'lng': lng});
  }

  static void subscribeToDelivery(String deliveryId, Function(Map) onUpdate) {
    // socket.on('delivery:$deliveryId', onUpdate);
  }
}

// ─── STORAGE SERVICE ─────────────────────
class StorageService {
  // En production: shared_preferences + flutter_secure_storage

  static Future<void> saveToken(String token) async {
    // await _secureStorage.write(key: 'auth_token', value: token);
  }

  static Future<String?> getToken() async {
    // return await _secureStorage.read(key: 'auth_token');
    return null;
  }

  static Future<void> clearAll() async {
    // await _secureStorage.deleteAll();
    // await _prefs.clear();
  }
}
