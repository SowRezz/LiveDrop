import 'package:flutter/material.dart';
import '../core/theme/app_theme.dart';

// ─── LIVE DROP BUTTON ─────────────────────
class LDButton extends StatelessWidget {
  final String label;
  final VoidCallback? onTap;
  final Color? color;
  final Color? textColor;
  final bool outline;
  final bool isLoading;
  final Widget? icon;
  final double? width;

  const LDButton({
    super.key,
    required this.label,
    this.onTap,
    this.color,
    this.textColor,
    this.outline = false,
    this.isLoading = false,
    this.icon,
    this.width,
  });

  @override
  Widget build(BuildContext context) {
    final bg = color ?? (outline ? Colors.transparent : AppColors.cyan);
    final fg = textColor ?? (outline ? AppColors.textSecondary : const Color(0xFF060C16));

    return GestureDetector(
      onTap: isLoading ? null : onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        width: width ?? double.infinity,
        height: 50,
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(10),
          border: outline ? Border.all(color: AppColors.border, width: 1) : null,
          boxShadow: !outline && onTap != null
              ? [BoxShadow(color: bg.withOpacity(0.25), blurRadius: 12, offset: const Offset(0, 4))]
              : null,
        ),
        child: Center(
          child: isLoading
              ? SizedBox(
                  width: 20, height: 20,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: fg,
                  ),
                )
              : Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (icon != null) ...[icon!, const SizedBox(width: 8)],
                    Text(
                      label,
                      style: TextStyle(
                        fontFamily: 'Syne',
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: fg,
                        letterSpacing: 0.4,
                      ),
                    ),
                  ],
                ),
        ),
      ),
    );
  }
}

// ─── LD CARD ─────────────────────────────
class LDCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets? padding;
  final Color? borderColor;
  final VoidCallback? onTap;
  final Color? color;
  final double? borderRadius;

  const LDCard({
    super.key,
    required this.child,
    this.padding,
    this.borderColor,
    this.onTap,
    this.color,
    this.borderRadius,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: padding ?? const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: color ?? AppColors.surface2,
          borderRadius: BorderRadius.circular(borderRadius ?? 16),
          border: Border.all(color: borderColor ?? AppColors.border, width: 1),
        ),
        child: child,
      ),
    );
  }
}

// ─── LD TAG ──────────────────────────────
class LDTag extends StatelessWidget {
  final String label;
  final Color color;
  final Color textColor;

  const LDTag({
    super.key,
    required this.label,
    required this.color,
    required this.textColor,
  });

  factory LDTag.cyan(String label) => LDTag(
        label: label,
        color: AppColors.cyan.withOpacity(0.12),
        textColor: AppColors.cyan,
      );

  factory LDTag.green(String label) => LDTag(
        label: label,
        color: AppColors.green.withOpacity(0.12),
        textColor: AppColors.green,
      );

  factory LDTag.yellow(String label) => LDTag(
        label: label,
        color: AppColors.yellow.withOpacity(0.12),
        textColor: AppColors.yellow,
      );

  factory LDTag.red(String label) => LDTag(
        label: label,
        color: AppColors.red.withOpacity(0.12),
        textColor: AppColors.red,
      );

  factory LDTag.orange(String label) => LDTag(
        label: label,
        color: AppColors.orange.withOpacity(0.12),
        textColor: AppColors.orange,
      );

  factory LDTag.purple(String label) => LDTag(
        label: label,
        color: AppColors.purple.withOpacity(0.12),
        textColor: AppColors.purple,
      );

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: textColor.withOpacity(0.25), width: 1),
      ),
      child: Text(
        label,
        style: TextStyle(
          fontFamily: 'SpaceMono',
          fontSize: 10,
          fontWeight: FontWeight.w500,
          color: textColor,
        ),
      ),
    );
  }
}

// ─── LD INPUT ────────────────────────────
class LDInput extends StatelessWidget {
  final String label;
  final String? hint;
  final TextEditingController? controller;
  final TextInputType? keyboardType;
  final bool obscureText;
  final String? Function(String?)? validator;
  final void Function(String)? onChanged;
  final Widget? prefix;
  final Widget? suffix;
  final int? maxLines;
  final bool readOnly;
  final VoidCallback? onTap;

  const LDInput({
    super.key,
    required this.label,
    this.hint,
    this.controller,
    this.keyboardType,
    this.obscureText = false,
    this.validator,
    this.onChanged,
    this.prefix,
    this.suffix,
    this.maxLines = 1,
    this.readOnly = false,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            fontFamily: 'SpaceMono',
            fontSize: 10,
            color: AppColors.textSecondary,
            letterSpacing: 0.08,
          ),
        ),
        const SizedBox(height: 6),
        TextFormField(
          controller: controller,
          keyboardType: keyboardType,
          obscureText: obscureText,
          validator: validator,
          onChanged: onChanged,
          maxLines: maxLines,
          readOnly: readOnly,
          onTap: onTap,
          style: const TextStyle(
            color: AppColors.textPrimary,
            fontSize: 13,
          ),
          decoration: InputDecoration(
            hintText: hint,
            prefixIcon: prefix,
            suffixIcon: suffix,
          ),
        ),
        const SizedBox(height: 12),
      ],
    );
  }
}

// ─── LIVE STATUS BADGE ───────────────────
class LiveStatusBadge extends StatefulWidget {
  final String label;
  const LiveStatusBadge({super.key, required this.label});

  @override
  State<LiveStatusBadge> createState() => _LiveStatusBadgeState();
}

class _LiveStatusBadgeState extends State<LiveStatusBadge>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _anim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    )..repeat(reverse: true);
    _anim = Tween<double>(begin: 0.3, end: 1.0).animate(
      CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: AppColors.green.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.green.withOpacity(0.2)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          AnimatedBuilder(
            animation: _anim,
            builder: (_, __) => Container(
              width: 6, height: 6,
              decoration: BoxDecoration(
                color: AppColors.green.withOpacity(_anim.value),
                shape: BoxShape.circle,
              ),
            ),
          ),
          const SizedBox(width: 5),
          Text(
            widget.label,
            style: const TextStyle(
              fontFamily: 'SpaceMono',
              fontSize: 9,
              color: AppColors.green,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}

// ─── PROGRESS STEPS ──────────────────────
class DeliveryProgressSteps extends StatelessWidget {
  final int currentStep; // 0-3
  final List<String> labels;

  const DeliveryProgressSteps({
    super.key,
    required this.currentStep,
    this.labels = const ['Commandé', 'Accepté', 'En route', 'Livré'],
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: List.generate(labels.length * 2 - 1, (i) {
        if (i.isOdd) {
          // Line
          final lineIndex = i ~/ 2;
          final isDone = lineIndex < currentStep;
          return Expanded(
            child: Container(
              height: 1.5,
              color: isDone ? AppColors.green : AppColors.border,
            ),
          );
        } else {
          // Step circle
          final stepIndex = i ~/ 2;
          final isDone = stepIndex < currentStep;
          final isActive = stepIndex == currentStep;
          return Column(
            children: [
              AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                width: 26, height: 26,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: isDone
                      ? AppColors.green
                      : isActive
                          ? AppColors.cyan
                          : AppColors.surface3,
                  border: Border.all(
                    color: isDone
                        ? AppColors.green
                        : isActive
                            ? AppColors.cyan
                            : AppColors.border,
                    width: 1.5,
                  ),
                  boxShadow: isActive
                      ? [BoxShadow(color: AppColors.cyan.withOpacity(0.4), blurRadius: 8)]
                      : null,
                ),
                child: Center(
                  child: isDone
                      ? const Icon(Icons.check, size: 14, color: Color(0xFF060C16))
                      : Text(
                          '${stepIndex + 1}',
                          style: TextStyle(
                            fontFamily: 'SpaceMono',
                            fontSize: 10,
                            fontWeight: FontWeight.w700,
                            color: isActive ? const Color(0xFF060C16) : AppColors.textTertiary,
                          ),
                        ),
                ),
              ),
              const SizedBox(height: 4),
              Text(
                labels[stepIndex],
                style: TextStyle(
                  fontSize: 9,
                  fontFamily: 'SpaceMono',
                  color: isDone || isActive ? AppColors.textSecondary : AppColors.textTertiary,
                ),
              ),
            ],
          );
        }
      }),
    );
  }
}

// ─── STAT BOX ────────────────────────────
class StatBox extends StatelessWidget {
  final String value;
  final String label;
  final Color valueColor;
  final String? delta;
  final bool deltaUp;

  const StatBox({
    super.key,
    required this.value,
    required this.label,
    this.valueColor = AppColors.cyan,
    this.delta,
    this.deltaUp = true,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surface2,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            value,
            style: TextStyle(
              fontFamily: 'Syne',
              fontSize: 22,
              fontWeight: FontWeight.w800,
              color: valueColor,
              letterSpacing: -0.5,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            label,
            style: const TextStyle(
              fontFamily: 'SpaceMono',
              fontSize: 10,
              color: AppColors.textSecondary,
            ),
          ),
          if (delta != null) ...[
            const SizedBox(height: 4),
            Text(
              delta!,
              style: TextStyle(
                fontSize: 10,
                color: deltaUp ? AppColors.green : AppColors.red,
              ),
            ),
          ],
        ],
      ),
    );
  }
}

// ─── SECTION HEADER ──────────────────────
class SectionHeader extends StatelessWidget {
  final String title;
  final String? action;
  final VoidCallback? onAction;

  const SectionHeader({
    super.key,
    required this.title,
    this.action,
    this.onAction,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontFamily: 'Syne',
              fontSize: 14,
              fontWeight: FontWeight.w600,
              color: AppColors.textPrimary,
            ),
          ),
          if (action != null)
            GestureDetector(
              onTap: onAction,
              child: Text(
                action!,
                style: const TextStyle(
                  fontSize: 11,
                  color: AppColors.cyan,
                ),
              ),
            ),
        ],
      ),
    );
  }
}

// ─── DIVIDER ─────────────────────────────
class LDDivider extends StatelessWidget {
  final String? label;
  const LDDivider({super.key, this.label});

  @override
  Widget build(BuildContext context) {
    if (label == null) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 10),
        child: Divider(color: AppColors.border, thickness: 1, height: 1),
      );
    }
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Row(
        children: [
          const Expanded(child: Divider(color: AppColors.border)),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Text(
              label!,
              style: const TextStyle(
                fontFamily: 'SpaceMono',
                fontSize: 10,
                color: AppColors.textTertiary,
              ),
            ),
          ),
          const Expanded(child: Divider(color: AppColors.border)),
        ],
      ),
    );
  }
}

// ─── ALERT BANNER ────────────────────────
class AlertBanner extends StatelessWidget {
  final String message;
  final AlertType type;

  const AlertBanner({super.key, required this.message, this.type = AlertType.info});

  @override
  Widget build(BuildContext context) {
    final Color color;
    switch (type) {
      case AlertType.info: color = AppColors.cyan; break;
      case AlertType.success: color = AppColors.green; break;
      case AlertType.warning: color = AppColors.orange; break;
      case AlertType.error: color = AppColors.red; break;
    }
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withOpacity(0.08),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: color.withOpacity(0.2)),
      ),
      child: Text(
        message,
        style: TextStyle(fontSize: 12, color: color, height: 1.4),
      ),
    );
  }
}

enum AlertType { info, success, warning, error }

// ─── PROGRESS BAR ────────────────────────
class LDProgressBar extends StatelessWidget {
  final double value; // 0.0 to 1.0
  final Color? color;
  final double height;

  const LDProgressBar({
    super.key,
    required this.value,
    this.color,
    this.height = 5,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: height,
      decoration: BoxDecoration(
        color: AppColors.surface3,
        borderRadius: BorderRadius.circular(height / 2),
      ),
      child: FractionallySizedBox(
        alignment: Alignment.centerLeft,
        widthFactor: value.clamp(0.0, 1.0),
        child: Container(
          decoration: BoxDecoration(
            color: color ?? AppColors.cyan,
            borderRadius: BorderRadius.circular(height / 2),
          ),
        ),
      ),
    );
  }
}

// ─── DRIVER BADGE ────────────────────────
class DriverStatusBadge extends StatelessWidget {
  final bool isOnline;
  const DriverStatusBadge({super.key, required this.isOnline});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: AppColors.surface3,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 8, height: 8,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: isOnline ? AppColors.green : AppColors.textTertiary,
              boxShadow: isOnline
                  ? [BoxShadow(color: AppColors.green.withOpacity(0.6), blurRadius: 6)]
                  : null,
            ),
          ),
          const SizedBox(width: 6),
          Text(
            isOnline ? 'En ligne' : 'Hors ligne',
            style: TextStyle(
              fontSize: 11,
              color: isOnline ? AppColors.textPrimary : AppColors.textSecondary,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }
}
