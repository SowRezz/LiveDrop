import 'dart:async';
import 'package:flutter/foundation.dart';
import '../models/models.dart';
import '../services/services.dart';

// ─── AUTH PROVIDER ────────────────────────
class AuthProvider extends ChangeNotifier {
  UserModel? _user;
  bool _isLoading = false;
  String? _error;

  UserModel? get user => _user;
  bool get isLoading => _isLoading;
  String? get error => _error;
  bool get isAuthenticated => _user != null;
  bool get isDriver => _user?.role == UserRole.driver;
  bool get isClient => _user?.role == UserRole.client;

  Future<bool> login(String email, String password) async {
    _isLoading = true;
    _error = null;
    notifyListeners();
    try {
      await Future.delayed(const Duration(milliseconds: 800));
      // Mock: accepte tout email/mdp valide
      if (email.contains('@') && password.length >= 6) {
        _user = email.contains('driver')
            ? UserModel(
                id: 'drv_usr_001',
                firstName: 'Karim',
                lastName: 'Benali',
                email: email,
                phone: '+33 6 55 44 33 22',
                role: UserRole.driver,
                rating: 4.9,
                totalDeliveries: 142,
                createdAt: DateTime(2023, 3, 1),
                isVerified: true,
              )
            : UserModel.mockClient;
        _isLoading = false;
        notifyListeners();
        return true;
      }
      throw Exception('Email ou mot de passe incorrect');
    } catch (e) {
      _error = e.toString().replaceAll('Exception: ', '');
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  Future<bool> register({
    required String firstName,
    required String lastName,
    required String email,
    required String phone,
    required String password,
    required UserRole role,
  }) async {
    _isLoading = true;
    _error = null;
    notifyListeners();
    try {
      await Future.delayed(const Duration(seconds: 1));
      _user = UserModel(
        id: 'usr_new_${DateTime.now().millisecondsSinceEpoch}',
        firstName: firstName,
        lastName: lastName,
        email: email,
        phone: phone,
        role: role,
        createdAt: DateTime.now(),
        isVerified: false,
      );
      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  void logout() {
    _user = null;
    notifyListeners();
  }

  void mockLoginAsClient() {
    _user = UserModel.mockClient;
    notifyListeners();
  }

  void mockLoginAsDriver() {
    _user = UserModel(
      id: 'drv_usr_001',
      firstName: 'Karim',
      lastName: 'Benali',
      email: 'karim@livedrop.fr',
      phone: '+33 6 55 44 33 22',
      role: UserRole.driver,
      rating: 4.9,
      totalDeliveries: 142,
      createdAt: DateTime(2023, 3, 1),
      isVerified: true,
    );
    notifyListeners();
  }
}

// ─── DELIVERY PROVIDER ────────────────────
class DeliveryProvider extends ChangeNotifier {
  DeliveryModel? _activeDelivery;
  List<DeliveryModel> _history = [];
  bool _isLoading = false;
  bool _isSearching = false;
  String? _error;

  // Create flow state
  LocationModel? _pickupLocation;
  LocationModel? _dropoffLocation;
  PackageModel? _package;
  RecipientModel? _recipient;
  bool _isImmediate = true;
  DateTime? _scheduledFor;

  DeliveryModel? get activeDelivery => _activeDelivery;
  List<DeliveryModel> get history => _history;
  bool get isLoading => _isLoading;
  bool get isSearching => _isSearching;
  String? get error => _error;
  LocationModel? get pickupLocation => _pickupLocation;
  LocationModel? get dropoffLocation => _dropoffLocation;
  PackageModel? get package => _package;
  RecipientModel? get recipient => _recipient;
  bool get isImmediate => _isImmediate;

  void setPickupLocation(LocationModel loc) {
    _pickupLocation = loc;
    notifyListeners();
  }

  void setDropoffLocation(LocationModel loc) {
    _dropoffLocation = loc;
    notifyListeners();
  }

  void setPackage(PackageModel pkg) {
    _package = pkg;
    notifyListeners();
  }

  void setRecipient(RecipientModel r) {
    _recipient = r;
    notifyListeners();
  }

  void setImmediate(bool val) {
    _isImmediate = val;
    notifyListeners();
  }

  double get estimatedDistance {
    if (_pickupLocation == null || _dropoffLocation == null) return 0;
    // Calcul simplifié (Haversine complet dans le service)
    final dlat = (_dropoffLocation!.lat - _pickupLocation!.lat).abs();
    final dlng = (_dropoffLocation!.lng - _pickupLocation!.lng).abs();
    return ((dlat + dlng) * 111).clamp(0.5, 50.0);
  }

  PricingModel? get currentPricing {
    if (_package == null) return null;
    return PricingModel.calculate(
      distanceKm: estimatedDistance,
      type: _package!.type,
      size: _package!.size,
      isInsured: _package!.isInsured,
    );
  }

  Future<bool> createDelivery(String clientId) async {
    if (_pickupLocation == null || _dropoffLocation == null || _package == null || _recipient == null) {
      _error = 'Informations manquantes';
      notifyListeners();
      return false;
    }
    _isLoading = true;
    notifyListeners();

    await Future.delayed(const Duration(milliseconds: 600));

    final pricing = currentPricing!;
    final delivery = DeliveryModel(
      id: 'del_${DateTime.now().millisecondsSinceEpoch}',
      clientId: clientId,
      pickupLocation: _pickupLocation!,
      dropoffLocation: _dropoffLocation!,
      package: _package!,
      recipient: _recipient!,
      pricing: pricing,
      status: DeliveryStatus.searching,
      pickupQrCode: 'LVR-${DateTime.now().millisecondsSinceEpoch}-PICKUP',
      dropoffQrCode: 'LVR-${DateTime.now().millisecondsSinceEpoch}-DROP',
      createdAt: DateTime.now(),
      distanceKm: estimatedDistance,
      durationMinutes: (estimatedDistance * 4).round() + 5,
    );

    _activeDelivery = delivery;
    _isLoading = false;
    notifyListeners();

    // Simuler la recherche et l'acceptation
    _simulateDriverSearch();
    return true;
  }

  void _simulateDriverSearch() {
    _isSearching = true;
    notifyListeners();
    Future.delayed(const Duration(seconds: 4), () {
      if (_activeDelivery != null) {
        _activeDelivery = _activeDelivery!.copyWith(
          driverId: 'drv_001',
          status: DeliveryStatus.accepted,
          acceptedAt: DateTime.now(),
        );
        _isSearching = false;
        notifyListeners();
      }
    });
  }

  void updateStatus(DeliveryStatus status) {
    if (_activeDelivery != null) {
      _activeDelivery = _activeDelivery!.copyWith(
        status: status,
        pickedUpAt: status == DeliveryStatus.pickedUp ? DateTime.now() : null,
        deliveredAt: status == DeliveryStatus.delivered ? DateTime.now() : null,
      );
      if (status == DeliveryStatus.delivered) {
        _history.insert(0, _activeDelivery!);
      }
      notifyListeners();
    }
  }

  void rateDelivery({required double rating, String? comment}) {
    if (_activeDelivery != null) {
      _activeDelivery = _activeDelivery!.copyWith(
        clientRating: rating,
        clientComment: comment,
      );
      notifyListeners();
    }
  }

  void loadMockHistory() {
    _history = [
      DeliveryModel.mock.copyWith(status: DeliveryStatus.delivered),
      DeliveryModel(
        id: 'del_hist_002',
        clientId: 'usr_001',
        driverId: 'drv_002',
        pickupLocation: const LocationModel(lat: 48.8448, lng: 2.3736, address: 'Nation', city: 'Paris'),
        dropoffLocation: const LocationModel(lat: 48.8502, lng: 2.4399, address: 'Vincennes', city: 'Val-de-Marne'),
        package: const PackageModel(type: PackageType.food, size: PackageSize.small),
        recipient: const RecipientModel(name: 'Thomas R.', phone: '+33 6 11 22 33 44'),
        pricing: PricingModel.calculate(distanceKm: 4.8, type: PackageType.food, size: PackageSize.small),
        status: DeliveryStatus.delivered,
        pickupQrCode: 'LVR-HIST-002-P',
        dropoffQrCode: 'LVR-HIST-002-D',
        createdAt: DateTime.now().subtract(const Duration(days: 5)),
        deliveredAt: DateTime.now().subtract(const Duration(days: 5)),
        distanceKm: 4.8,
        durationMinutes: 22,
        clientRating: 5.0,
      ),
      DeliveryModel(
        id: 'del_hist_003',
        clientId: 'usr_001',
        driverId: 'drv_003',
        pickupLocation: const LocationModel(lat: 48.8910, lng: 2.2364, address: 'IKEA Plaisir', city: 'Plaisir'),
        dropoffLocation: const LocationModel(lat: 48.8610, lng: 2.4380, address: 'Montreuil', city: 'Montreuil'),
        package: const PackageModel(type: PackageType.furniture, size: PackageSize.xxl),
        recipient: const RecipientModel(name: 'Marie D.', phone: '+33 6 12 34 56 78'),
        pricing: PricingModel.calculate(distanceKm: 18.5, type: PackageType.furniture, size: PackageSize.xxl),
        status: DeliveryStatus.delivered,
        pickupQrCode: 'LVR-HIST-003-P',
        dropoffQrCode: 'LVR-HIST-003-D',
        createdAt: DateTime.now().subtract(const Duration(days: 12)),
        deliveredAt: DateTime.now().subtract(const Duration(days: 12)),
        distanceKm: 18.5,
        durationMinutes: 45,
        clientRating: 4.8,
      ),
    ];
    notifyListeners();
  }

  void loadMockActive() {
    _activeDelivery = DeliveryModel.mock;
    notifyListeners();
  }

  void resetCreateFlow() {
    _pickupLocation = null;
    _dropoffLocation = null;
    _package = null;
    _recipient = null;
    _isImmediate = true;
    notifyListeners();
  }
}

// ─── DRIVER PROVIDER ──────────────────────
class DriverProvider extends ChangeNotifier {
  DriverModel? _driver;
  List<MissionModel> _availableMissions = [];
  MissionModel? _activeMission;
  bool _isOnline = true;
  bool _isLoading = false;
  Timer? _missionTimer;
  int _timerSeconds = 45;

  DriverModel? get driver => _driver;
  List<MissionModel> get availableMissions => _availableMissions;
  MissionModel? get activeMission => _activeMission;
  bool get isOnline => _isOnline;
  bool get isLoading => _isLoading;
  int get timerSeconds => _timerSeconds;

  void loadDriver() {
    _driver = DriverModel.mock;
    _availableMissions = MissionModel.mockList;
    notifyListeners();
  }

  void toggleOnline() {
    _isOnline = !_isOnline;
    if (!_isOnline) _availableMissions = [];
    else _availableMissions = MissionModel.mockList;
    notifyListeners();
  }

  void acceptMission(MissionModel mission) {
    _activeMission = mission;
    _availableMissions.removeWhere((m) => m.deliveryId == mission.deliveryId);
    _stopTimer();
    notifyListeners();
  }

  void refuseMission(String deliveryId) {
    _availableMissions.removeWhere((m) => m.deliveryId == deliveryId);
    _stopTimer();
    notifyListeners();
  }

  void startMissionTimer(VoidCallback onTimeout) {
    _timerSeconds = 45;
    _missionTimer?.cancel();
    _missionTimer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (_timerSeconds > 0) {
        _timerSeconds--;
        notifyListeners();
      } else {
        _stopTimer();
        onTimeout();
      }
    });
  }

  void _stopTimer() {
    _missionTimer?.cancel();
    _timerSeconds = 45;
  }

  void completeDelivery({required double rating}) {
    if (_driver != null) {
      _driver = DriverModel(
        id: _driver!.id,
        userId: _driver!.userId,
        firstName: _driver!.firstName,
        lastName: _driver!.lastName,
        phone: _driver!.phone,
        rating: ((_driver!.rating * _driver!.totalDeliveries + rating) / (_driver!.totalDeliveries + 1)),
        totalDeliveries: _driver!.totalDeliveries + 1,
        vehicleType: _driver!.vehicleType,
        vehicleBrand: _driver!.vehicleBrand,
        vehiclePlate: _driver!.vehiclePlate,
        isOnline: _driver!.isOnline,
        isVerified: _driver!.isVerified,
        currentLocation: _driver!.currentLocation,
        todayEarnings: _driver!.todayEarnings + (_activeMission?.driverEarnings ?? 0),
        todayDeliveries: _driver!.todayDeliveries + 1,
        weekEarnings: _driver!.weekEarnings + (_activeMission?.driverEarnings ?? 0),
        currentStreak: _driver!.currentStreak + 1,
        acceptanceRate: _driver!.acceptanceRate,
        score: _driver!.score,
        avatarUrl: _driver!.avatarUrl,
      );
      _activeMission = null;
      notifyListeners();
    }
  }

  @override
  void dispose() {
    _missionTimer?.cancel();
    super.dispose();
  }
}

// ─── LOCATION PROVIDER ────────────────────
class LocationProvider extends ChangeNotifier {
  LocationModel? _currentLocation;
  bool _isTracking = false;
  List<LocationModel> _driverPath = [];

  LocationModel? get currentLocation => _currentLocation;
  bool get isTracking => _isTracking;
  List<LocationModel> get driverPath => _driverPath;

  void updateCurrentLocation(LocationModel loc) {
    _currentLocation = loc;
    notifyListeners();
  }

  void startTracking() {
    _isTracking = true;
    _currentLocation = const LocationModel(
      lat: 48.8558,
      lng: 2.3595,
      address: 'En route',
    );
    notifyListeners();
    // Simuler le mouvement du livreur
    Timer.periodic(const Duration(seconds: 3), (t) {
      if (!_isTracking) { t.cancel(); return; }
      final cur = _currentLocation!;
      _currentLocation = LocationModel(
        lat: cur.lat + (0.0002 * (DateTime.now().second % 2 == 0 ? 1 : -0.5)),
        lng: cur.lng + 0.0003,
        address: 'En route',
      );
      _driverPath.add(_currentLocation!);
      notifyListeners();
    });
  }

  void stopTracking() {
    _isTracking = false;
    _driverPath.clear();
    notifyListeners();
  }
}

// ─── CHAT PROVIDER ────────────────────────
class ChatProvider extends ChangeNotifier {
  final List<ChatMessage> _messages = [];
  bool _isLoading = false;

  List<ChatMessage> get messages => _messages;
  bool get isLoading => _isLoading;

  void loadMockMessages(String clientId, String driverId) {
    _messages.clear();
    _messages.addAll(ChatMessage.mockThread(clientId, driverId));
    notifyListeners();
  }

  Future<void> sendMessage({
    required String senderId,
    required String content,
  }) async {
    final msg = ChatMessage(
      id: 'msg_${DateTime.now().millisecondsSinceEpoch}',
      senderId: senderId,
      content: content,
      sentAt: DateTime.now(),
    );
    _messages.add(msg);
    notifyListeners();

    // Mock auto-réponse du livreur
    if (senderId != 'drv_001') {
      await Future.delayed(const Duration(seconds: 2));
      _messages.add(ChatMessage(
        id: 'msg_auto_${DateTime.now().millisecondsSinceEpoch}',
        senderId: 'drv_001',
        content: "D'accord, je prends note ! À bientôt 🛵",
        sentAt: DateTime.now(),
      ));
      notifyListeners();
    }
  }
}

// ─── NOTIFICATION PROVIDER ────────────────
class NotificationProvider extends ChangeNotifier {
  final List<NotificationModel> _notifications = [];
  int get unreadCount => _notifications.where((n) => !n.isRead).length;
  List<NotificationModel> get notifications => _notifications;

  void addMockNotifications() {
    _notifications.addAll([
      NotificationModel(
        id: 'notif_1',
        title: 'Livreur en route',
        body: 'Karim est à 8 min de vous',
        type: 'driver_en_route',
        createdAt: DateTime.now().subtract(const Duration(minutes: 8)),
        isRead: false,
        routeTo: '/tracking',
      ),
      NotificationModel(
        id: 'notif_2',
        title: 'Paiement confirmé',
        body: '8,06 € débité avec succès',
        type: 'payment_confirmed',
        createdAt: DateTime.now().subtract(const Duration(minutes: 13)),
        isRead: false,
      ),
      NotificationModel(
        id: 'notif_3',
        title: 'Livreur trouvé !',
        body: 'Karim a accepté votre commande',
        type: 'driver_found',
        createdAt: DateTime.now().subtract(const Duration(minutes: 13)),
        isRead: true,
      ),
      NotificationModel(
        id: 'notif_4',
        title: '5 € de crédit offert',
        body: 'Parrainage accepté — Merci !',
        type: 'promo',
        createdAt: DateTime.now().subtract(const Duration(days: 1)),
        isRead: true,
      ),
    ]);
    notifyListeners();
  }

  void markAllRead() {
    // Can't modify const, use list replacement in production
    notifyListeners();
  }
}
