import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class AppColors {
  // Backgrounds
  static const Color bg = Color(0xFF080C14);
  static const Color surface1 = Color(0xFF0D1220);
  static const Color surface2 = Color(0xFF131926);
  static const Color surface3 = Color(0xFF1A2235);
  static const Color surface4 = Color(0xFF222D44);

  // Accents
  static const Color cyan = Color(0xFF00C8FF);
  static const Color cyanDark = Color(0xFF0098CC);
  static const Color yellow = Color(0xFFF5E642);
  static const Color yellowDark = Color(0xFFD4C52E);
  static const Color green = Color(0xFF00F59B);
  static const Color red = Color(0xFFFF3D5A);
  static const Color orange = Color(0xFFFF8C42);
  static const Color purple = Color(0xFF8B5CF6);

  // Text
  static const Color textPrimary = Color(0xFFDCE4F0);
  static const Color textSecondary = Color(0xFF5E6E8A);
  static const Color textTertiary = Color(0xFF3A4560);

  // Border
  static const Color border = Color(0x12FFFFFF);
  static const Color borderCyan = Color(0x26C8FF00);
}

class AppTheme {
  static ThemeData get darkTheme => ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: AppColors.bg,
        colorScheme: const ColorScheme.dark(
          background: AppColors.bg,
          surface: AppColors.surface1,
          primary: AppColors.cyan,
          secondary: AppColors.yellow,
          error: AppColors.red,
          onBackground: AppColors.textPrimary,
          onSurface: AppColors.textPrimary,
          onPrimary: Color(0xFF060C16),
        ),
        fontFamily: 'DM Sans',
        textTheme: const TextTheme(
          displayLarge: TextStyle(
            fontFamily: 'Syne',
            fontSize: 40,
            fontWeight: FontWeight.w800,
            color: AppColors.textPrimary,
            letterSpacing: -1.5,
          ),
          displayMedium: TextStyle(
            fontFamily: 'Syne',
            fontSize: 28,
            fontWeight: FontWeight.w700,
            color: AppColors.textPrimary,
            letterSpacing: -0.5,
          ),
          headlineLarge: TextStyle(
            fontFamily: 'Syne',
            fontSize: 22,
            fontWeight: FontWeight.w700,
            color: AppColors.textPrimary,
          ),
          headlineMedium: TextStyle(
            fontFamily: 'Syne',
            fontSize: 18,
            fontWeight: FontWeight.w700,
            color: AppColors.textPrimary,
          ),
          headlineSmall: TextStyle(
            fontFamily: 'Syne',
            fontSize: 15,
            fontWeight: FontWeight.w600,
            color: AppColors.textPrimary,
          ),
          bodyLarge: TextStyle(
            fontSize: 15,
            fontWeight: FontWeight.w400,
            color: AppColors.textPrimary,
          ),
          bodyMedium: TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w400,
            color: AppColors.textSecondary,
          ),
          bodySmall: TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w400,
            color: AppColors.textTertiary,
            fontFamily: 'SpaceMono',
          ),
          labelLarge: TextStyle(
            fontFamily: 'Syne',
            fontSize: 14,
            fontWeight: FontWeight.w700,
            letterSpacing: 0.5,
          ),
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: AppColors.bg,
          elevation: 0,
          centerTitle: false,
          systemOverlayStyle: SystemUiOverlayStyle(
            statusBarColor: Colors.transparent,
            statusBarIconBrightness: Brightness.light,
          ),
        ),
        cardTheme: CardTheme(
          color: AppColors.surface2,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: const BorderSide(color: AppColors.border, width: 1),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: AppColors.surface2,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: const BorderSide(color: AppColors.border),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: const BorderSide(color: AppColors.border),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: const BorderSide(color: AppColors.cyan, width: 1.5),
          ),
          hintStyle: const TextStyle(color: AppColors.textTertiary, fontSize: 13),
          contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.cyan,
            foregroundColor: const Color(0xFF060C16),
            elevation: 0,
            minimumSize: const Size(double.infinity, 50),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            textStyle: const TextStyle(
              fontFamily: 'Syne',
              fontSize: 14,
              fontWeight: FontWeight.w700,
              letterSpacing: 0.5,
            ),
          ),
        ),
        outlinedButtonTheme: OutlinedButtonThemeData(
          style: OutlinedButton.styleFrom(
            foregroundColor: AppColors.textSecondary,
            side: const BorderSide(color: AppColors.border),
            minimumSize: const Size(double.infinity, 50),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            textStyle: const TextStyle(
              fontFamily: 'Syne',
              fontSize: 14,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        bottomNavigationBarTheme: const BottomNavigationBarThemeData(
          backgroundColor: AppColors.surface1,
          selectedItemColor: AppColors.cyan,
          unselectedItemColor: AppColors.textTertiary,
          selectedLabelStyle: TextStyle(
            fontFamily: 'SpaceMono',
            fontSize: 9,
            fontWeight: FontWeight.w700,
          ),
          unselectedLabelStyle: TextStyle(
            fontFamily: 'SpaceMono',
            fontSize: 9,
          ),
          type: BottomNavigationBarType.fixed,
          elevation: 0,
        ),
        dividerTheme: const DividerThemeData(
          color: AppColors.border,
          thickness: 1,
          space: 1,
        ),
        snackBarTheme: SnackBarThemeData(
          backgroundColor: AppColors.surface3,
          contentTextStyle: const TextStyle(color: AppColors.textPrimary, fontSize: 13),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          behavior: SnackBarBehavior.floating,
        ),
      );
}
