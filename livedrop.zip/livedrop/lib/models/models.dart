// ─────────────────────────────────────────
// MODELS — LiveDrop
// ─────────────────────────────────────────

enum UserRole { client, driver }
enum DeliveryStatus { pending, searching, accepted, pickedUp, inTransit, delivered, cancelled }
enum PackageType { parcel, food, furniture, document, medicine, flowers, other }
enum PackageSize { small, medium, large, xxl }
enum VehicleType { bike, moto, car, van }
enum PaymentMethod { card, applePay, googlePay, wallet }

// ─── USER ────────────────────────────────
class UserModel {
  final String id;
  final String firstName;
  final String lastName;
  final String email;
  final String phone;
  final UserRole role;
  final double rating;
  final int totalDeliveries;
  final double walletBalance;
  final List<String> savedAddresses;
  final List<PaymentCardModel> paymentCards;
  final DateTime createdAt;
  final bool isVerified;
  final String? avatarUrl;

  const UserModel({
    required this.id,
    required this.firstName,
    required this.lastName,
    required this.email,
    required this.phone,
    required this.role,
    this.rating = 5.0,
    this.totalDeliveries = 0,
    this.walletBalance = 0.0,
    this.savedAddresses = const [],
    this.paymentCards = const [],
    required this.createdAt,
    this.isVerified = false,
    this.avatarUrl,
  });

  String get fullName => '$firstName $lastName';
  String get displayName => '$firstName ${lastName[0]}.';

  factory UserModel.fromJson(Map<String, dynamic> json) => UserModel(
        id: json['id'],
        firstName: json['firstName'],
        lastName: json['lastName'],
        email: json['email'],
        phone: json['phone'],
        role: UserRole.values.byName(json['role']),
        rating: (json['rating'] as num).toDouble(),
        totalDeliveries: json['totalDeliveries'] ?? 0,
        walletBalance: (json['walletBalance'] as num?)?.toDouble() ?? 0.0,
        createdAt: DateTime.parse(json['createdAt']),
        isVerified: json['isVerified'] ?? false,
        avatarUrl: json['avatarUrl'],
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'firstName': firstName,
        'lastName': lastName,
        'email': email,
        'phone': phone,
        'role': role.name,
        'rating': rating,
        'totalDeliveries': totalDeliveries,
        'walletBalance': walletBalance,
        'createdAt': createdAt.toIso8601String(),
        'isVerified': isVerified,
        'avatarUrl': avatarUrl,
      };

  static UserModel get mockClient => UserModel(
        id: 'usr_001',
        firstName: 'Marie',
        lastName: 'Dupont',
        email: 'marie.dupont@email.fr',
        phone: '+33 6 12 34 56 78',
        role: UserRole.client,
        rating: 4.8,
        totalDeliveries: 12,
        walletBalance: 5.00,
        createdAt: DateTime(2024, 1, 15),
        isVerified: true,
        paymentCards: [PaymentCardModel.mock],
      );
}

// ─── PAYMENT CARD ────────────────────────
class PaymentCardModel {
  final String id;
  final String last4;
  final String brand;
  final String expiryMonth;
  final String expiryYear;
  final bool isDefault;

  const PaymentCardModel({
    required this.id,
    required this.last4,
    required this.brand,
    required this.expiryMonth,
    required this.expiryYear,
    this.isDefault = false,
  });

  String get displayNumber => '•••• •••• •••• $last4';
  String get expiry => '$expiryMonth/$expiryYear';

  static PaymentCardModel get mock => const PaymentCardModel(
        id: 'card_001',
        last4: '4242',
        brand: 'Visa',
        expiryMonth: '09',
        expiryYear: '27',
        isDefault: true,
      );
}

// ─── LOCATION ────────────────────────────
class LocationModel {
  final double lat;
  final double lng;
  final String address;
  final String? city;
  final String? postalCode;

  const LocationModel({
    required this.lat,
    required this.lng,
    required this.address,
    this.city,
    this.postalCode,
  });

  factory LocationModel.fromJson(Map<String, dynamic> json) => LocationModel(
        lat: (json['lat'] as num).toDouble(),
        lng: (json['lng'] as num).toDouble(),
        address: json['address'],
        city: json['city'],
        postalCode: json['postalCode'],
      );

  Map<String, dynamic> toJson() => {
        'lat': lat,
        'lng': lng,
        'address': address,
        'city': city,
        'postalCode': postalCode,
      };

  static LocationModel get bastille => const LocationModel(
        lat: 48.8533,
        lng: 2.3692,
        address: '12 Rue de la Bastille',
        city: 'Paris',
        postalCode: '75004',
      );

  static LocationModel get opera => const LocationModel(
        lat: 48.8719,
        lng: 2.3316,
        address: "8 Avenue de l'Opéra",
        city: 'Paris',
        postalCode: '75001',
      );
}

// ─── PACKAGE ─────────────────────────────
class PackageModel {
  final PackageType type;
  final PackageSize size;
  final String description;
  final double? weightKg;
  final double? declaredValue;
  final String? instructions;
  final bool isFragile;
  final bool isInsured;
  final String? photoUrl;

  const PackageModel({
    required this.type,
    required this.size,
    this.description = '',
    this.weightKg,
    this.declaredValue,
    this.instructions,
    this.isFragile = false,
    this.isInsured = false,
    this.photoUrl,
  });

  String get typeEmoji {
    switch (type) {
      case PackageType.parcel: return '📦';
      case PackageType.food: return '🍔';
      case PackageType.furniture: return '🛋️';
      case PackageType.document: return '📄';
      case PackageType.medicine: return '💊';
      case PackageType.flowers: return '🌸';
      default: return '📦';
    }
  }

  String get typeLabel {
    switch (type) {
      case PackageType.parcel: return 'Colis';
      case PackageType.food: return 'Nourriture';
      case PackageType.furniture: return 'Meuble';
      case PackageType.document: return 'Document';
      case PackageType.medicine: return 'Médicament';
      case PackageType.flowers: return 'Fleurs';
      default: return 'Autre';
    }
  }

  String get sizeLabel {
    switch (size) {
      case PackageSize.small: return 'Petit (≤ 2 kg)';
      case PackageSize.medium: return 'Moyen (≤ 10 kg)';
      case PackageSize.large: return 'Grand (≤ 30 kg)';
      case PackageSize.xxl: return 'XXL (> 30 kg)';
    }
  }
}

// ─── PRICING ─────────────────────────────
class PricingModel {
  final double baseFare;
  final double distanceFare;
  final double typeSurcharge;
  final double insuranceFee;
  final double discount;
  final double total;
  final double driverEarnings;
  final double platformCommission;

  const PricingModel({
    required this.baseFare,
    required this.distanceFare,
    this.typeSurcharge = 0,
    this.insuranceFee = 0,
    this.discount = 0,
    required this.total,
    required this.driverEarnings,
    required this.platformCommission,
  });

  static PricingModel calculate({
    required double distanceKm,
    required PackageType type,
    required PackageSize size,
    bool isInsured = false,
    double promoDiscount = 0,
  }) {
    const double base = 2.50;
    const double perKm = 0.80;
    final double distFare = distanceKm * perKm;

    double typeSurch = 0;
    switch (type) {
      case PackageType.furniture: typeSurch = 15.0; break;
      case PackageType.food: typeSurch = 0.5; break;
      case PackageType.medicine: typeSurch = 1.0; break;
      default: typeSurch = 0;
    }

    double sizeSurch = 0;
    switch (size) {
      case PackageSize.small: sizeSurch = 0; break;
      case PackageSize.medium: sizeSurch = 1.0; break;
      case PackageSize.large: sizeSurch = 3.0; break;
      case PackageSize.xxl: sizeSurch = 10.0; break;
    }

    final double insurFee = isInsured ? 2.0 : 0.0;
    final double subtotal = base + distFare + typeSurch + sizeSurch + insurFee;
    final double total = subtotal - promoDiscount;
    final double commission = total * 0.20;
    final double driverEarn = total - commission;

    return PricingModel(
      baseFare: base,
      distanceFare: distFare,
      typeSurcharge: typeSurch + sizeSurch,
      insuranceFee: insurFee,
      discount: promoDiscount,
      total: total,
      driverEarnings: driverEarn,
      platformCommission: commission,
    );
  }
}

// ─── RECIPIENT ───────────────────────────
class RecipientModel {
  final String name;
  final String phone;
  final String? email;

  const RecipientModel({
    required this.name,
    required this.phone,
    this.email,
  });
}

// ─── DELIVERY ────────────────────────────
class DeliveryModel {
  final String id;
  final String clientId;
  final String? driverId;
  final LocationModel pickupLocation;
  final LocationModel dropoffLocation;
  final PackageModel package;
  final RecipientModel recipient;
  final PricingModel pricing;
  final DeliveryStatus status;
  final String pickupQrCode;
  final String dropoffQrCode;
  final DateTime createdAt;
  final DateTime? acceptedAt;
  final DateTime? pickedUpAt;
  final DateTime? deliveredAt;
  final double? distanceKm;
  final int? durationMinutes;
  final bool isScheduled;
  final DateTime? scheduledFor;
  final String? proofPhotoUrl;
  final double? clientRating;
  final double? driverRating;
  final String? clientComment;

  const DeliveryModel({
    required this.id,
    required this.clientId,
    this.driverId,
    required this.pickupLocation,
    required this.dropoffLocation,
    required this.package,
    required this.recipient,
    required this.pricing,
    this.status = DeliveryStatus.pending,
    required this.pickupQrCode,
    required this.dropoffQrCode,
    required this.createdAt,
    this.acceptedAt,
    this.pickedUpAt,
    this.deliveredAt,
    this.distanceKm,
    this.durationMinutes,
    this.isScheduled = false,
    this.scheduledFor,
    this.proofPhotoUrl,
    this.clientRating,
    this.driverRating,
    this.clientComment,
  });

  bool get isActive =>
      status == DeliveryStatus.accepted ||
      status == DeliveryStatus.pickedUp ||
      status == DeliveryStatus.inTransit;

  String get statusLabel {
    switch (status) {
      case DeliveryStatus.pending: return 'En attente';
      case DeliveryStatus.searching: return 'Recherche livreur';
      case DeliveryStatus.accepted: return 'Livreur trouvé';
      case DeliveryStatus.pickedUp: return 'Colis récupéré';
      case DeliveryStatus.inTransit: return 'En route';
      case DeliveryStatus.delivered: return 'Livré';
      case DeliveryStatus.cancelled: return 'Annulé';
    }
  }

  DeliveryModel copyWith({
    String? driverId,
    DeliveryStatus? status,
    DateTime? acceptedAt,
    DateTime? pickedUpAt,
    DateTime? deliveredAt,
    double? clientRating,
    double? driverRating,
    String? clientComment,
    String? proofPhotoUrl,
  }) =>
      DeliveryModel(
        id: id,
        clientId: clientId,
        driverId: driverId ?? this.driverId,
        pickupLocation: pickupLocation,
        dropoffLocation: dropoffLocation,
        package: package,
        recipient: recipient,
        pricing: pricing,
        status: status ?? this.status,
        pickupQrCode: pickupQrCode,
        dropoffQrCode: dropoffQrCode,
        createdAt: createdAt,
        acceptedAt: acceptedAt ?? this.acceptedAt,
        pickedUpAt: pickedUpAt ?? this.pickedUpAt,
        deliveredAt: deliveredAt ?? this.deliveredAt,
        distanceKm: distanceKm,
        durationMinutes: durationMinutes,
        clientRating: clientRating ?? this.clientRating,
        driverRating: driverRating ?? this.driverRating,
        clientComment: clientComment ?? this.clientComment,
        proofPhotoUrl: proofPhotoUrl ?? this.proofPhotoUrl,
      );

  static DeliveryModel get mock => DeliveryModel(
        id: 'del_001',
        clientId: 'usr_001',
        driverId: 'drv_001',
        pickupLocation: LocationModel.bastille,
        dropoffLocation: LocationModel.opera,
        package: const PackageModel(
          type: PackageType.parcel,
          size: PackageSize.medium,
          description: 'Boîte en carton avec livres',
          weightKg: 3.5,
          declaredValue: 150,
          isFragile: true,
          isInsured: true,
        ),
        recipient: const RecipientModel(name: 'Jean Martin', phone: '+33 6 98 76 54 32'),
        pricing: PricingModel.calculate(
          distanceKm: 3.2,
          type: PackageType.parcel,
          size: PackageSize.medium,
          isInsured: true,
        ),
        status: DeliveryStatus.inTransit,
        pickupQrCode: 'LVR-2024-8472-PICKUP',
        dropoffQrCode: 'LVR-2024-8472-DROP',
        createdAt: DateTime.now().subtract(const Duration(minutes: 15)),
        acceptedAt: DateTime.now().subtract(const Duration(minutes: 13)),
        distanceKm: 3.2,
        durationMinutes: 18,
      );
}

// ─── DRIVER ──────────────────────────────
class DriverModel {
  final String id;
  final String userId;
  final String firstName;
  final String lastName;
  final String phone;
  final double rating;
  final int totalDeliveries;
  final VehicleType vehicleType;
  final String vehicleBrand;
  final String vehiclePlate;
  final bool isOnline;
  final bool isVerified;
  final LocationModel? currentLocation;
  final double todayEarnings;
  final int todayDeliveries;
  final double weekEarnings;
  final int currentStreak;
  final double acceptanceRate;
  final ScoreModel score;
  final String? avatarUrl;

  const DriverModel({
    required this.id,
    required this.userId,
    required this.firstName,
    required this.lastName,
    required this.phone,
    this.rating = 5.0,
    this.totalDeliveries = 0,
    required this.vehicleType,
    required this.vehicleBrand,
    required this.vehiclePlate,
    this.isOnline = false,
    this.isVerified = false,
    this.currentLocation,
    this.todayEarnings = 0,
    this.todayDeliveries = 0,
    this.weekEarnings = 0,
    this.currentStreak = 0,
    this.acceptanceRate = 100,
    required this.score,
    this.avatarUrl,
  });

  String get fullName => '$firstName $lastName';
  String get displayName => '$firstName ${lastName[0]}.';

  String get vehicleEmoji {
    switch (vehicleType) {
      case VehicleType.bike: return '🚲';
      case VehicleType.moto: return '🏍️';
      case VehicleType.car: return '🚗';
      case VehicleType.van: return '🚐';
    }
  }

  static DriverModel get mock => DriverModel(
        id: 'drv_001',
        userId: 'usr_drv_001',
        firstName: 'Karim',
        lastName: 'Benali',
        phone: '+33 6 55 44 33 22',
        rating: 4.9,
        totalDeliveries: 142,
        vehicleType: VehicleType.moto,
        vehicleBrand: 'Honda CB500F',
        vehiclePlate: 'AB-123-CD',
        isOnline: true,
        isVerified: true,
        currentLocation: const LocationModel(
          lat: 48.8600,
          lng: 2.3500,
          address: 'En route',
        ),
        todayEarnings: 47.50,
        todayDeliveries: 6,
        weekEarnings: 247.80,
        currentStreak: 7,
        acceptanceRate: 98,
        score: ScoreModel.excellent,
      );
}

// ─── SCORE ───────────────────────────────
class ScoreModel {
  final double punctuality;
  final double packageCare;
  final double communication;
  final double routeCompliance;
  final double overall;

  const ScoreModel({
    required this.punctuality,
    required this.packageCare,
    required this.communication,
    required this.routeCompliance,
    required this.overall,
  });

  static ScoreModel get excellent => const ScoreModel(
        punctuality: 0.95,
        packageCare: 0.98,
        communication: 0.92,
        routeCompliance: 1.0,
        overall: 4.9,
      );
}

// ─── MISSION ─────────────────────────────
class MissionModel {
  final String deliveryId;
  final LocationModel pickupLocation;
  final LocationModel dropoffLocation;
  final PackageModel package;
  final double totalAmount;
  final double driverEarnings;
  final double distanceToPickupKm;
  final double totalDistanceKm;
  final int estimatedMinutes;
  final String clientName;
  final double clientRating;
  final String? clientInstructions;
  final DateTime postedAt;
  final int timeoutSeconds;

  const MissionModel({
    required this.deliveryId,
    required this.pickupLocation,
    required this.dropoffLocation,
    required this.package,
    required this.totalAmount,
    required this.driverEarnings,
    required this.distanceToPickupKm,
    required this.totalDistanceKm,
    required this.estimatedMinutes,
    required this.clientName,
    required this.clientRating,
    this.clientInstructions,
    required this.postedAt,
    this.timeoutSeconds = 45,
  });

  static List<MissionModel> get mockList => [
        MissionModel(
          deliveryId: 'del_001',
          pickupLocation: LocationModel.bastille,
          dropoffLocation: LocationModel.opera,
          package: const PackageModel(
            type: PackageType.parcel,
            size: PackageSize.medium,
            isFragile: true,
            isInsured: true,
          ),
          totalAmount: 8.06,
          driverEarnings: 6.45,
          distanceToPickupKm: 1.2,
          totalDistanceKm: 3.2,
          estimatedMinutes: 18,
          clientName: 'Marie D.',
          clientRating: 4.8,
          clientInstructions: 'Colis fragile. Code porte : B465. 3e étage.',
          postedAt: DateTime.now().subtract(const Duration(seconds: 20)),
        ),
        MissionModel(
          deliveryId: 'del_002',
          pickupLocation: const LocationModel(lat: 48.8602, lng: 2.3477, address: 'Châtelet', city: 'Paris'),
          dropoffLocation: const LocationModel(lat: 48.8867, lng: 2.3431, address: 'Montmartre', city: 'Paris'),
          package: const PackageModel(type: PackageType.food, size: PackageSize.small),
          totalAmount: 11.25,
          driverEarnings: 9.00,
          distanceToPickupKm: 2.8,
          totalDistanceKm: 5.1,
          estimatedMinutes: 25,
          clientName: 'Thomas R.',
          clientRating: 4.6,
          postedAt: DateTime.now().subtract(const Duration(seconds: 5)),
        ),
        MissionModel(
          deliveryId: 'del_003',
          pickupLocation: const LocationModel(lat: 48.8448, lng: 2.3736, address: 'Nation', city: 'Paris'),
          dropoffLocation: const LocationModel(lat: 48.8502, lng: 2.4399, address: 'Vincennes', city: 'Val-de-Marne'),
          package: const PackageModel(type: PackageType.document, size: PackageSize.small),
          totalAmount: 9.50,
          driverEarnings: 7.60,
          distanceToPickupKm: 3.5,
          totalDistanceKm: 6.8,
          estimatedMinutes: 30,
          clientName: 'Sophie L.',
          clientRating: 5.0,
          postedAt: DateTime.now().subtract(const Duration(seconds: 45)),
        ),
      ];
}

// ─── CHAT MESSAGE ─────────────────────────
class ChatMessage {
  final String id;
  final String senderId;
  final String content;
  final DateTime sentAt;
  final bool isRead;

  const ChatMessage({
    required this.id,
    required this.senderId,
    required this.content,
    required this.sentAt,
    this.isRead = false,
  });

  static List<ChatMessage> mockThread(String clientId, String driverId) => [
        ChatMessage(
          id: 'msg_1',
          senderId: driverId,
          content: 'Bonjour ! Je suis en route vers votre adresse 🛵',
          sentAt: DateTime.now().subtract(const Duration(minutes: 13)),
          isRead: true,
        ),
        ChatMessage(
          id: 'msg_2',
          senderId: clientId,
          content: "Parfait merci ! L'interphone est le B465",
          sentAt: DateTime.now().subtract(const Duration(minutes: 12)),
          isRead: true,
        ),
        ChatMessage(
          id: 'msg_3',
          senderId: driverId,
          content: 'Ok pas de problème, j\'arrive dans ~5 min !',
          sentAt: DateTime.now().subtract(const Duration(minutes: 11)),
          isRead: true,
        ),
      ];
}

// ─── NOTIFICATION ─────────────────────────
class NotificationModel {
  final String id;
  final String title;
  final String body;
  final String type;
  final DateTime createdAt;
  final bool isRead;
  final String? routeTo;

  const NotificationModel({
    required this.id,
    required this.title,
    required this.body,
    required this.type,
    required this.createdAt,
    this.isRead = false,
    this.routeTo,
  });
}

// ─── EARNINGS PERIOD ──────────────────────
class EarningsPeriod {
  final DateTime date;
  final double amount;
  final int deliveries;

  const EarningsPeriod({
    required this.date,
    required this.amount,
    required this.deliveries,
  });

  static List<EarningsPeriod> get mockWeek => [
        EarningsPeriod(date: DateTime.now().subtract(const Duration(days: 6)), amount: 35.20, deliveries: 5),
        EarningsPeriod(date: DateTime.now().subtract(const Duration(days: 5)), amount: 52.10, deliveries: 7),
        EarningsPeriod(date: DateTime.now().subtract(const Duration(days: 4)), amount: 28.40, deliveries: 4),
        EarningsPeriod(date: DateTime.now().subtract(const Duration(days: 3)), amount: 61.80, deliveries: 9),
        EarningsPeriod(date: DateTime.now().subtract(const Duration(days: 2)), amount: 44.50, deliveries: 6),
        EarningsPeriod(date: DateTime.now().subtract(const Duration(days: 1)), amount: 47.50, deliveries: 6),
        EarningsPeriod(date: DateTime.now(), amount: 22.30, deliveries: 3),
      ];
}
